#if defined(TURBOWRITER64)
#define EXEADDR 0x03F00040
#elif defined(TURBOWRITER32)
#define EXEADDR 0x01F00040
#elif defined(TURBOWRITER16)
#define EXEADDR 0x0F00040
#endif
