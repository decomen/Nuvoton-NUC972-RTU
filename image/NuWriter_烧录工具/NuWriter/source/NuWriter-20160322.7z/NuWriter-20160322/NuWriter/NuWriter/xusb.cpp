#include "stdafx.h"
#include "NuWriter.h"
#include "NuWriterDlg.h"
#include "NucWinUsb.h"
//#include "enumser.h"

//#include "strsafe.h"
#define BATCH_BURN
unsigned char * DDR2Buf(char *buf,int buflen,int *ddrlen);
//const UCHAR usb_count=sizeof(usbdesc)/sizeof(USB_DESC);

int GetFileLength(CString& filename)
{
	FILE* rfp;
	int fileSize;
	if( (rfp=_wfopen(filename, _T("rb")))==NULL )
	{
		AfxMessageBox(_T("ERROR: Can't open file !"));
		fclose(rfp);
		return -1;
	}

	fseek(rfp, 0,SEEK_END);
	fileSize=ftell(rfp);
	fclose(rfp);

	return fileSize;
	
}

DWORD atox(CString& str)
{
	DWORD value;
	swscanf_s(str,_T("%x"),&value);
	return value;
}


MaxOffset GetMaxOffset(CIniFile& inifile,CString keyname)
{
	MaxOffset maxdata;
	CString nostr;
	UINT32 offset;
	int image_index=inifile.FindKeyX(_T("Image "));

	maxdata.maxoffset=0;

	for(int k=7;k>=0;k--)
	{
		if((1<<k)&image_index)
		{
			nostr.Format(_T("Image %d"),k);
			offset=atox(inifile.GetValue(nostr,keyname));
			if(offset>=maxdata.maxoffset)
			{
				maxdata.maxoffset=offset;
				maxdata.imageno=k;
			}
		}

	}

	return maxdata;
}

BOOL OffsetLess (MaxOffset e1, MaxOffset e2 )
{
    return e1.maxoffset < e2.maxoffset;
}


VOID SortbyOffset(CIniFile& inifile,CString keyname,vector<MaxOffset>& vect)
{
	MaxOffset maxdata;
	CString nostr;
	UINT32 offset;
	int image_index=inifile.FindKeyX(_T("Image "));

	maxdata.maxoffset=0;

	for(int k=7;k>=0;k--)
	{
		if((1<<k)&image_index)
		{
			nostr.Format(_T("Image %d"),k);
			offset=atox(inifile.GetValue(nostr,keyname));
		
			maxdata.maxoffset=offset;
			maxdata.imageno=k;

			vect.push_back(maxdata);
		
		}

	}
	sort(vect.begin(), vect.end(), OffsetLess);

	return ;
}

BOOL Auto_Detect(CString& portName,CString& tempName)
{
	BOOL bResult = TRUE;	
	bResult=NucUsb.EnableWinUsbDevice();	
	if(bResult==TRUE)
	{
		tempName.Format(_T(" Connected"));
		portName.Format(_T("Nuvoton VCOM"));
	}
	NucUsb.NUC_CloseHandle();
	return (bResult);
}

BOOLEAN DataCompare(char* base,char* src,int len)
{
	int i=0;
	for(i=0;i<len;i++)
	{
		if(base[i]!=src[i])
			return FALSE;
	}

	return TRUE;
}


unsigned char * DDR2Buf(char *buf,int buflen,int *ddrlen)
{
	unsigned char *ddrbuf;
	*ddrlen=((buflen+8+15)/16)*16;
	ddrbuf=(unsigned char *)malloc(sizeof(unsigned char)*(*ddrlen));
	memset(ddrbuf,0x0,*ddrlen);
	*(ddrbuf+0)=0x55;
	*(ddrbuf+1)=0xAA;
	*(ddrbuf+2)=0x55;
	*(ddrbuf+3)=0xAA;
	*((unsigned int *)(ddrbuf+4))=(buflen/8);        /* len */
	memcpy((ddrbuf+8),buf,buflen);
	return ddrbuf;
}
/************** SDRAM Begin ************/

BOOL CRAMDlg::XUSB(CString& portName,CString& m_pathName)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	FILE* fp;
	int pos=0;
	SDRAM_RAW_TYPEHEAD fhead;
	unsigned int total,file_len,scnt,rcnt,ack;
	char* lpBuffer;

		bResult=NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}

		USHORT typeack=0x0;
		bResult=NucUsb.NUC_SetType(0,SDRAM,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("typeack failed !!!\n"));
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];

		fp=_wfopen(m_pathName,_T("rb"));

		if(!fp)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}

		fseek(fp,0,SEEK_END);
		file_len=ftell(fp);
		fseek(fp,0,SEEK_SET);

		if(!file_len)
		{
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}
		
		fhead.flag=WRITE_ACTION;
		fhead.filelen=file_len;
		swscanf_s(m_address,_T("%x"),&fhead.address);

		if(m_autorun)
		{
			fhead.address|=NEED_AUTORUN;
		}

		memcpy(lpBuffer,(unsigned char*)&fhead,sizeof(SDRAM_RAW_TYPEHEAD));		
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(SDRAM_RAW_TYPEHEAD));
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write SDRAM head error\n"));
			return FALSE;
		}		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("SDRAM head ack error\n"));
			return FALSE;
		}

		scnt=file_len/BUF_SIZE;
		rcnt=file_len%BUF_SIZE;

		total=0;
		while(scnt>0)
		{

			fread(lpBuffer,BUF_SIZE,1,fp);
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer,BUF_SIZE);
			
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}

			 if(bResult==TRUE)
			 {
				total+=BUF_SIZE;

				pos=(int)(((float)(((float)total/(float)file_len))*100));
				posstr.Format(_T("%d%%"),pos);		
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
				if(bResult==FALSE || ack!=BUF_SIZE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));               
					return FALSE;
				}

			 }else{
				 	delete []lpBuffer;					
					NucUsb.NUC_CloseHandle();
					fclose(fp);					
					return FALSE;
			 }

			 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			 {
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			 }

			 scnt--;

			 if(pos%5==0)
			 {
				PostMessage(WM_SDRAM_PROGRESS,(LPARAM)pos,0);
			 }

			 
		}

		if(rcnt>0)
		{
			fread(lpBuffer,rcnt,1,fp);
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer,rcnt);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}
			
			if(bResult==TRUE)
			{
				total+=rcnt;
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
				if(bResult==FALSE)
				{
					delete []lpBuffer;					
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				}

			}else{
					delete []lpBuffer;					
					NucUsb.NUC_CloseHandle();
					fclose(fp);					
					return FALSE;
			}

			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}

			pos=(int)(((float)(((float)total/(float)file_len))*100));

			if(pos>=100)
			{
				pos=100;
			}
			posstr.Format(_T("%d%%"),pos);

			if(pos%5==0)
			{
				PostMessage(WM_SDRAM_PROGRESS,(LPARAM)pos,0);
			}
			
		}

	delete []lpBuffer;
	fclose(fp);
	NucUsb.NUC_CloseHandle();
	return TRUE;

}
/************** SDRAM End ************/

/************** SPI Begin ************/
BOOL CSPIDlg::XUSB_Pack(CString& portName,CString& m_pathName,int *len)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	FILE* fp;
	int pos=0;
	UCHAR burn_pos=0;
	unsigned int total,file_len,scnt,rcnt;
	ULONG ack;
	//NORBOOT_NAND_HEAD fhead;
	char* lpBuffer;
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);

		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack=0x0;
		bResult=NucUsb.NUC_SetType(0,SPI,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}
	
		
		fp=_wfopen(m_pathName,_T("rb"));
  
		if(!fp)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}

		fseek(fp,0,SEEK_END);
		file_len=ftell(fp);
		fseek(fp,0,SEEK_SET);

		if(!file_len)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}
		
		lpBuffer = new char[file_len]; //read file to buffer
		memset(lpBuffer,0x00,file_len);		

		memset((unsigned char*)m_fhead,0,sizeof(NORBOOT_NAND_HEAD));
		total=0;
		m_fhead->flag=PACK_ACTION;			
		m_fhead->type=m_type;	
		m_fhead->filelen=file_len;
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));	

		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write SPI head error\n")); 
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}
		
		fread(lpBuffer,m_fhead->filelen,1,fp);
		if(lpBuffer[0]!=0x5) 
		{
			AfxMessageBox(_T("This file is not pack image"));
		}
		fclose(fp);


		char *pbuf = lpBuffer;	
		PACK_HEAD *ppackhead=(PACK_HEAD *)lpBuffer;
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, sizeof(PACK_HEAD));		
		Sleep(5);
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)	return FALSE;
		if(bResult!=TRUE) return FALSE;
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}
		total+= sizeof(PACK_HEAD);
		pbuf+= sizeof(PACK_HEAD);

		PACK_CHILD_HEAD child;
		m_progress.SetRange(0,short(ppackhead->num*200));
		int posnum=0;
		for(int i=0;i<(int)(ppackhead->num);i++)
		{
			memcpy(&child,(char *)pbuf,sizeof(PACK_CHILD_HEAD));
			//Sleep(20);
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, sizeof(PACK_CHILD_HEAD));			
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)	return FALSE;
			if(bResult!=TRUE) return FALSE;
			total+= sizeof(PACK_CHILD_HEAD);
			pbuf+= sizeof(PACK_CHILD_HEAD);
			
				scnt=child.filelen/BUF_SIZE;
				rcnt=child.filelen%BUF_SIZE;				
			
				while(scnt>0)
				{		
					//Sleep(20);
					bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BUF_SIZE);					
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						fclose(fp);				
						return FALSE;
					}

					 if(bResult==TRUE)
					 {
						pbuf+=BUF_SIZE;
						total+=BUF_SIZE;

						pos=(int)(((float)(((float)total/(float)file_len))*100));
						posstr.Format(_T("%d%%"),pos);
						
						DbgOut("SPI wait ack");
						bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
						DbgOut("SPI wait ack end");
				
						if(bResult==FALSE)
						{
							delete []lpBuffer;
							NucUsb.NUC_CloseHandle();
							fclose(fp);
							AfxMessageBox(_T("ACK error !"));
							return FALSE;
						}

					 }

					 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					 {						
						return FALSE;
					 }

					 scnt--;

					 if(pos%5==0)
					 {
						PostMessage(WM_SPI_PROGRESS,(LPARAM)(posnum+pos),0);
					 }
				 
				}

				if(rcnt>0)
				{			
					//Sleep(20);
					bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);					
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{						
						delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						return FALSE;
					}

					//printf("upload %%.2f\r",((float)total/file_len)*100);										
					if(bResult==TRUE)
					{
						pbuf+=rcnt;
						total+=rcnt;								
						DbgOut("SPI wait ack");
						bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);			
						DbgOut("SPI wait ack end");

						if(bResult==FALSE)
						{
							delete []lpBuffer;
							NucUsb.NUC_CloseHandle();
							fclose(fp);
							AfxMessageBox(_T("ACK error !"));
							return FALSE;
						
						}

					}

					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						//fclose(fp);
						return FALSE;
					}

					pos=(int)(((float)(((float)total/(float)file_len))*100));

					if(pos>=100)
					{
						pos=100;
					}
					posstr.Format(_T("%d%%"),pos);

					if(pos%5==0)
					{
					
						PostMessage(WM_SPI_PROGRESS,(LPARAM)(posnum+pos),0);
					}
					
				}			
	
					

				posnum+=100;
				//fclose(fp);
			//burn progress...
				burn_pos=0;
				//PostMessage(WM_SPI_PROGRESS,(LPARAM)0,0);
				m_progress.SetBkColor(COLOR_BURN);
				
				while(burn_pos!=100)
				{
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						return FALSE;
					}

					DbgOut("SPI wait burn ack");
					bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
					if(bResult==FALSE)
					{
						NucUsb.NUC_CloseHandle();
						AfxMessageBox(_T("ACK error !"));
						return FALSE;
					}
					DbgOut("SPI wait burn ack end");
					if(!((ack>>16)&0xffff))
					{
						burn_pos=(UCHAR)(ack&0xffff);
						PostMessage(WM_SPI_PROGRESS,(LPARAM)(posnum+burn_pos),0);
					}
					else
					{
						NucUsb.NUC_CloseHandle();
						AfxMessageBox(_T("Burn error"));
						return FALSE;
					}						
				}
				posnum+=100;
		}

	delete []lpBuffer;
	NucUsb.NUC_CloseHandle();
	return TRUE;

}

BOOL CSPIDlg::XUSB_Burn(CString& portName,CString& m_pathName,int *len)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	FILE* fp;
	int pos=0;
	UCHAR burn_pos=0;
	unsigned int total,file_len,scnt,rcnt;
	ULONG ack;
	//NORBOOT_NAND_HEAD fhead;
	char* lpBuffer;
	unsigned char *ddrbuf;
	int ddrlen;	
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
     m_progress.SetRange(0,100);
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack=0x0;
		bResult=NucUsb.NUC_SetType(0,SPI,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}
	
		
		fp=_wfopen(m_pathName,_T("rb"));
  
		if(!fp)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}

		fseek(fp,0,SEEK_END);
		file_len=ftell(fp);
		fseek(fp,0,SEEK_SET);

		if(!file_len)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}
		
		
		memset((unsigned char*)m_fhead,0,sizeof(NORBOOT_NAND_HEAD));
		
		m_fhead->flag=WRITE_ACTION;
		((NORBOOT_NAND_HEAD *)m_fhead)->initSize=0;

		//check AES------------------------------		
		if(m_spi_enc_check.GetCheck()==TRUE)
			file_len=((file_len+15)/16)*16;		
		m_fhead->filelen=file_len;

#if 1
		switch(m_type)
		{
			case DATA:			
			case PACK:
				swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				*len=file_len;
				lpBuffer = new char[file_len]; //read file to buffer
				memset(lpBuffer,0xff,file_len);					
				((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;								
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);
				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
			break;
			case ENV:
				swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				if(file_len>(0x10000-4))
				{
					//delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("The environment file size is less then 64KB\n"));
					return FALSE;
				}				
				lpBuffer = new char[0x10000]; //read file to buffer
				memset(lpBuffer,0x00,0x10000);		
			
				((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;
								
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);
				m_fhead->filelen=0x10000;
				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
			break;
			case UBOOT:
				swscanf_s(_T("1"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				//-------------------DDR---------------------						
				ddrbuf=DDR2Buf(mainWnd->DDRBuf,mainWnd->DDRLen,&ddrlen);
				file_len=file_len+ddrlen;
				((NORBOOT_NAND_HEAD *)m_fhead)->initSize=ddrlen;				
				//-------------------------------------------
				*len=file_len;
				lpBuffer = new char[file_len]; //read file to buffer
				memset(lpBuffer,0xff,file_len);						
					((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;
				
				
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);

				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
			break;
		}
#else
		if(m_type!=UBOOT)
		{
			swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
			swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
			swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
			*len=file_len;			
			
		}else
		{	
			swscanf_s(_T("1"),_T("%d"),&m_fhead->no);
			swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
			swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
			//-------------------DDR---------------------						
			ddrbuf=DDR2Buf(mainWnd->DDRBuf,mainWnd->DDRLen,&ddrlen);
			file_len=file_len+ddrlen;
			((NORBOOT_NAND_HEAD *)m_fhead)->initSize=ddrlen;				
			//-------------------------------------------
			*len=file_len;
		}
		

		lpBuffer = new char[file_len]; //read file to buffer
		memset(lpBuffer,0xff,file_len);

		CString mactmp;						
		((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;
		

	//	for(int i=0;i<6;i++)
	//	  ((NORBOOT_NAND_HEAD2 *)m_fhead)->macaddr[i]=i*10;


		wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);

		m_fhead->type=m_type;			
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));	
#endif
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write SPI head error\n")); 
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}
#if 1
		switch(m_type)
		{
			case DATA:		
				if(m_spi_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer,m_fhead->filelen,1,fp);
				else{
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);					
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					if(encbuf!=NULL)
					{
						free(encbuf);
						encbuf=NULL;
					}
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&enclen);
					if(encbuf==NULL) 
					{
						if(lpBuffer!=NULL) delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						fclose(fp);
						AfxMessageBox(_T("AES encrpt failed or AES value equal to zero"));
						return FALSE;
					}
					memcpy(lpBuffer,encbuf,enclen);	
				}
			break;
			case PACK:
				fread(lpBuffer,m_fhead->filelen,1,fp);				
			break;
			case ENV:
				#if 0
				fread(lpBuffer+4,file_len,1,fp);
				#else
				{
					char line[256];
					char* ptr=(char *)(lpBuffer+4);
					while (1) {
						 if (fgets(line,256, fp) == NULL) break;
						 if(line[strlen(line)-2]==0x0D || line[strlen(line)-1]==0x0A)
						 {
							strncpy(ptr,line,strlen(line)-1);
							ptr[strlen(line)-2]=0x0;
							ptr+=(strlen(line)-1);
						 }else{
							 strncpy(ptr,line,strlen(line));
							 ptr+=(strlen(line));
						 }
					}
				
				}
				#endif
				
				*(unsigned int *)lpBuffer=mainWnd->CalculateCRC32((unsigned char *)(lpBuffer+4),0x10000-4);
				*len=file_len=0x10000;	
				if(mainWnd->envbuf!=NULL) free(mainWnd->envbuf);
				mainWnd->envbuf=(unsigned char *)malloc(0x10000);
				memcpy(mainWnd->envbuf,lpBuffer,0x10000);
			break;
			case UBOOT:
				memcpy(lpBuffer,ddrbuf,ddrlen);			
				//------AES--------------------------------------------
				if(m_spi_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer+ddrlen,m_fhead->filelen,1,fp);
				else{
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);					
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					if(encbuf!=NULL)
					{
						free(encbuf);
						encbuf=NULL;
					}
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&enclen);
					if(encbuf==NULL) 
					{
						if(lpBuffer!=NULL) delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						fclose(fp);
						AfxMessageBox(_T("AES encrpt failed or AES value equal to zero"));
						return FALSE;
					}
					memcpy(lpBuffer+ddrlen,encbuf,enclen);	
				}
				break;
		}
#else
		if(m_type==UBOOT){
				memcpy(lpBuffer,ddrbuf,ddrlen);			
				//------AES--------------------------------------------
				if(m_spi_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer+ddrlen,m_fhead->filelen,1,fp);
				else{
					char *encbuf;
					unsigned int len;
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&len);
					memcpy(lpBuffer+ddrlen,encbuf,len);				
				}
				//-----------------------------------------------------
		}else{
			fread(lpBuffer,m_fhead->filelen,1,fp);
		}
#endif
		scnt=file_len/BUF_SIZE;
		rcnt=file_len%BUF_SIZE;

		total=0;
		char *pbuf = lpBuffer;	
		while(scnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BUF_SIZE);
			pbuf+=BUF_SIZE;
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);				
				return FALSE;
			}

			 if(bResult==TRUE)
			 {
				total+=BUF_SIZE;

				pos=(int)(((float)(((float)total/(float)file_len))*100));
				posstr.Format(_T("%d%%"),pos);
				
				DbgOut("SPI wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
				DbgOut("SPI wait ack end");
		
				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				}

			 }

			 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			 {
				fclose(fp);
				return FALSE;
			 }

			 scnt--;

			 if(pos%5==0)
			 {
				PostMessage(WM_SPI_PROGRESS,(LPARAM)pos,0);
			 }
		 
		}

		if(rcnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				return FALSE;
			}

			//printf("upload %%.2f\r",((float)total/file_len)*100);
			
			
			if(bResult==TRUE)
			{
				total+=rcnt;								
				DbgOut("SPI wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);			
				DbgOut("SPI wait ack end");

				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				
				}

			}

			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				return FALSE;
			}

			pos=(int)(((float)(((float)total/(float)file_len))*100));

			if(pos>=100)
			{
				pos=100;
			}
			posstr.Format(_T("%d%%"),pos);

			if(pos%5==0)
			{
			
				PostMessage(WM_SPI_PROGRESS,(LPARAM)pos,0);
			}
			
		}

	delete []lpBuffer;
	fclose(fp);
//burn progress...
	burn_pos=0;
	PostMessage(WM_SPI_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_BURN);
	
	while(burn_pos!=100)
	{
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			return FALSE;
		}

		DbgOut("SPI wait burn ack");
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}
		DbgOut("SPI wait burn ack end");
		if(!((ack>>16)&0xffff))
		{
			burn_pos=(UCHAR)(ack&0xffff);
			PostMessage(WM_SPI_PROGRESS,(LPARAM)burn_pos,0);
		}
		else
		{
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("Burn error"));
			return FALSE;
		}

	}
	NucUsb.NUC_CloseHandle();
	return TRUE;

}

//SPI Verify
BOOL CSPIDlg::XUSB_Verify(CString& portName,CString& m_pathName)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	FILE* fp;
	int pos=0;
	//NORBOOT_NAND_HEAD fhead;
	unsigned int total=0,file_len,scnt,rcnt,ack;
	char* lpBuffer;
	char temp[BUF_SIZE];
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
	PostMessage(WM_SPI_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_VERIFY);

	/***********************************************/
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack;
		bResult=NucUsb.NUC_SetType(0,SPI,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];
		fp=_wfopen(m_pathName,_T("rb"));

		if(!fp)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}

		if(m_type!=ENV)
		{
			if(m_spi_enc_check.GetCheck()!=TRUE)
			{
				fseek(fp,0,SEEK_END);
				file_len=ftell(fp);
				fseek(fp,0,SEEK_SET);
			}else
				file_len=enclen;
		}else{
			file_len=0x10000;
		}

		if(!file_len)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}
		
		m_fhead->flag=VERIFY_ACTION;		
		
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));

		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write SPI head error\n"));
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}

		scnt=file_len/BUF_SIZE;
		rcnt=file_len%BUF_SIZE;

		total=0;
		while(scnt>0)
		{

			if(m_type!=ENV)
			{
				if(m_spi_enc_check.GetCheck()!=TRUE)				
					fread(temp,BUF_SIZE,1,fp);
				else{
					memcpy(temp,encbuf+total,BUF_SIZE);
				}
			}
			else{
				memcpy(temp,mainWnd->envbuf+total,BUF_SIZE);
			}
			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer, BUF_SIZE);			
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}

			if(bResult==TRUE)
			 {
				total+=BUF_SIZE;

				pos=(int)(((float)(((float)total/(float)file_len))*100));
				posstr.Format(_T("%d%%"),pos);

				if(DataCompare(temp,lpBuffer,BUF_SIZE))
					ack=BUF_SIZE;
				else
					ack=0;//compare error
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);		
				if((bResult==FALSE)||(!ack))
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					return FALSE;
				}

			 }
			 else
			 {
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				fclose(fp);
				return FALSE;
			 }

			 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			 {
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			 }

			 scnt--;

			 if(pos%5==0)
			 {
				PostMessage(WM_SPI_PROGRESS,(LPARAM)pos,0);
			 }

			 
		}

		if(rcnt>0)
		{
			if(m_type!=ENV)
			{				
				if(m_spi_enc_check.GetCheck()!=TRUE)				
					fread(temp,rcnt,1,fp);
				else{
					memcpy(temp,encbuf+total,rcnt);
				}
			}
			else{
				memcpy(temp,mainWnd->envbuf+total,rcnt);
			}
			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}
			
			if(bResult==TRUE)
			{
				total+=rcnt;
				if(DataCompare(temp,lpBuffer,rcnt))
					ack=BUF_SIZE;
				else
					ack=0;//compare error
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack, 4);
				if((bResult==FALSE)||(!ack))
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					return FALSE;
				
				}

			}
			 else
			 {
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();	
				fclose(fp);
				return FALSE;
			 }

			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}

			pos=(int)(((float)(((float)total/(float)file_len))*100));

			if(pos>=100)
			{
				pos=100;
			}
			posstr.Format(_T("%d%%"),pos);

			if(pos%5==0)
			{
				PostMessage(WM_SPI_PROGRESS,(LPARAM)pos,0);
			}
			
		}

	delete []lpBuffer;
	fclose(fp);
	NucUsb.NUC_CloseHandle();
	return TRUE;

}

// xusb read
BOOL CSPIDlg::XUSB_Read(CString& portName,CString& m_pathName,unsigned int addr,unsigned int len)
//BOOL CSPIDlg::XUSB_Read(CString& portName,CString& m_pathName)
{
#if 1
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	int pos=0;
	//NORBOOT_NAND_HEAD fhead;
	unsigned int total=0,scnt,rcnt,ack;
	char* lpBuffer;
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
	PostMessage(WM_SPI_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_VERIFY);

	/***********************************************/
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack;
		bResult=NucUsb.NUC_SetType(0,SPI,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];
		FILE* tempfp;
		//-----------------------------------			
		tempfp=_wfopen(m_pathName,_T("w+b"));
		//-----------------------------------	
		if(!tempfp)
		{
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}	

		m_fhead->flag=READ_ACTION;		
		m_fhead->flashoffset=addr;
		m_fhead->filelen=len;
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));

		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("Write SPI head error\n"));
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}

	scnt=len/BUF_SIZE;
	rcnt=len%BUF_SIZE;
	total=0;
	while(scnt>0)
	{		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{		
			total+=BUF_SIZE;
			pos=(int)(((float)(((float)total/(float)len))*100));				
			posstr.Format(_T("%d%%"),pos);	
			fwrite(lpBuffer,BUF_SIZE,1,tempfp);			
			ack=BUF_SIZE;			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);			
			if(bResult==FALSE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();				
				return FALSE;
			}			
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			return FALSE;
		}
		
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}		
		
		scnt--;
 		if(pos%5==0)
		{
			PostMessage(WM_SPI_PROGRESS,(LPARAM)pos,0);
		}
	}
	
	if(rcnt>0)
	{			 		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);			
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{
			total+=rcnt;
			fwrite(lpBuffer,rcnt,1,tempfp);			
			ack=BUF_SIZE;		
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);
			if(bResult!=TRUE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();			
				return FALSE;
			}
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();		
			return FALSE;	
		}
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;		
			return FALSE;
		}	
		pos=(int)(((float)(((float)total/(float)len))*100));
		if(pos>=100)
		{
			pos=100;
		}	
		posstr.Format(_T("%d%%"),pos);
		if(pos%5==0)
		{
			PostMessage(WM_SPI_PROGRESS,(LPARAM)pos,0);
		}	
	}
	delete []lpBuffer;	
	NucUsb.NUC_CloseHandle();
	fclose(tempfp);	
	/********************************************/		
	return TRUE;

#else //org

	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;	
	int pos=0;
	//SDRAM_RAW_TYPEHEAD fhead;
	unsigned int total,file_len,scnt,rcnt,ack;
	char* lpBuffer;	

	PostMessage(WM_SPI_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_DOWNLOAD);
	/***********************************************/
	NucUsb.EnableWinUsbDevice();
	bResult=NucUsb.NUC_CheckFw(0);
	if(bResult==FALSE) 
	{
		AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
		return FALSE;
	}		
	USHORT typeack;
	bResult=NucUsb.NUC_SetType(0,RAWSPI,(UCHAR *)&typeack,sizeof(typeack));
	if(bResult==FALSE) 
	{
		NucUsb.NUC_CloseHandle();
		return FALSE;
	}
	lpBuffer = new char[BUF_SIZE];	
	
	FILE* tempfp;
	//-----------------------------------			
	tempfp=_wfopen(m_pathName,_T("w+b"));
	//-----------------------------------	
	if(!tempfp)
	{
		AfxMessageBox(_T("File Open error\n"));
		return FALSE;
	}
	//--------------------
	int nblock=_wtoi(m_blocks);
	file_len=nblock*64*1024;
	//---------------------
	//file_len=2*1024*1024;
	m_frawhead.flag=VERIFY_ACTION;
	m_frawhead.filelen=file_len;
	m_frawhead.address=0;	
	memcpy(lpBuffer,(unsigned char*)&m_frawhead,sizeof(SDRAM_RAW_TYPEHEAD));
	bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(SDRAM_RAW_TYPEHEAD));
	if(bResult==FALSE)
	{
		delete []lpBuffer;
		NucUsb.NUC_CloseHandle();		
		AfxMessageBox(_T("Write RAW NOR head error\n"));
		return FALSE;
	}	
	bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
	if(bResult==FALSE)
	{
		delete []lpBuffer;
		NucUsb.NUC_CloseHandle();		
		AfxMessageBox(_T("ACK error !"));
		return FALSE;
	}		
	scnt=file_len/BUF_SIZE;
	rcnt=file_len%BUF_SIZE;
	total=0;
	while(scnt>0)
	{		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{		
			total+=BUF_SIZE;
			pos=(int)(((float)(((float)total/(float)file_len))*100));				
			posstr.Format(_T("%d%%"),pos);	
			fwrite(lpBuffer,BUF_SIZE,1,tempfp);			
			ack=BUF_SIZE;			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);			
			if(bResult==FALSE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();				
				return FALSE;
			}			
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			return FALSE;
		}
		
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}		
		
		scnt--;
 		if(pos%5==0)
		{
			PostMessage(WM_SPI_PROGRESS,(LPARAM)pos,0);
		}
	}
	
	if(rcnt>0)
	{			 		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);			
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{
			total+=rcnt;
			fwrite(lpBuffer,rcnt,1,tempfp);			
			ack=BUF_SIZE;		
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);
			if(bResult!=4)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();			
				return FALSE;
			}
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();		
			return FALSE;	
		}
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;		
			return FALSE;
		}	
		pos=(int)(((float)(((float)total/(float)file_len))*100));
		if(pos>=100)
		{
			pos=100;
		}	
		posstr.Format(_T("%d%%"),pos);
		if(pos%5==0)
		{
			PostMessage(WM_SPI_PROGRESS,(LPARAM)pos,0);
		}	
	}
	delete []lpBuffer;	
	NucUsb.NUC_CloseHandle();
	fclose(tempfp);	
	/********************************************/	
	return TRUE;
#endif
}

BOOL CSPIDlg::XUSB_Erase(CString& portName)
{
	BOOL bResult;
	CString tempstr;
	int count=0;
	unsigned int ack,erase_pos=0;
	NORBOOT_NAND_HEAD *fhead;
	char* lpBuffer;
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
	fhead=(NORBOOT_NAND_HEAD *)malloc(sizeof(NORBOOT_NAND_HEAD));

	/***********************************************/
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			free(fhead);
			return FALSE;
		}
		USHORT typeack;
		bResult=NucUsb.NUC_SetType(0,SPI,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			free(fhead);
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];

		memset((unsigned char*)fhead,0,sizeof(NORBOOT_NAND_HEAD));
		fhead->flag=ERASE_ACTION;
		fhead->flashoffset = _wtoi(m_sblocks); //start erase block
		fhead->execaddr=_wtoi(m_blocks);  //erase block length
		fhead->type=m_erase_flag; // Decide chip erase mode or erase mode
		if(m_erase_flag==0)		
			fhead->no=0xffffffff;//erase all
		else
			fhead->no=0x0;//erase all
		memcpy(lpBuffer,(unsigned char*)fhead,sizeof(NORBOOT_NAND_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
		free(fhead);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("Write SPI head error\n"));			
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE || ack!=0x85)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();	
			CString msg;
			msg.Format(_T("ACK error 0x%08x\n"),ack);
			AfxMessageBox(msg);
			return FALSE;
		}

		erase_pos=0;
		int wait_pos=0;
		while(erase_pos!=100)
		{
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				AfxMessageBox(_T("WaitForSingleObject error !"));
				return FALSE;
			}

			DbgOut("NAND wait erase ack");				
			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
			if(bResult=FALSE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				AfxMessageBox(_T("ACK error !"));
				return FALSE;
			}

			DbgOut("NAND wait erase ack end");
			if(!((ack>>16)&0xffff))
			{
				erase_pos=ack&0xffff;
				PostMessage(WM_SPI_PROGRESS,(LPARAM)erase_pos,0);
			}
			else
			{
				
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				CString msg;
				msg.Format(_T("Erase error ack=0x%08x\n"),ack);
				AfxMessageBox(msg);
				return FALSE;
			}

			if(erase_pos==95)
			{
				wait_pos++;
				if(wait_pos>100)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					AfxMessageBox(_T("Erase error"));
					return FALSE;
				}
					
			}

		}

	
	delete []lpBuffer;
	NucUsb.NUC_CloseHandle();
	return TRUE;

}
/************** SPI End ************/

/************** MMC Begin ************/
BOOL CMMCDlg::XUSB_Pack(CString& portName,CString& m_pathName,int *len)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	FILE* fp;
	int pos=0;
	UCHAR burn_pos=0;
	unsigned int total,file_len,scnt,rcnt;
	ULONG ack;
	//NORBOOT_NAND_HEAD fhead;
	char* lpBuffer;
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);

		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack=0x0;
		bResult=NucUsb.NUC_SetType(0,MMC,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}
	
		
		fp=_wfopen(m_pathName,_T("rb"));
  
		if(!fp)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}

		fseek(fp,0,SEEK_END);
		file_len=ftell(fp);
		fseek(fp,0,SEEK_SET);

		if(!file_len)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}

		unsigned int magic;
		fread((unsigned char *)&magic,4,1,fp);
		if(magic!=0x5)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Pack Image Format Error\n"));
			return FALSE;
		}
		fseek(fp,0,SEEK_SET);
		
		lpBuffer = new char[file_len]; //read file to buffer
		memset(lpBuffer,0x00,file_len);		

		memset((unsigned char*)m_fhead,0,sizeof(NORBOOT_MMC_HEAD));
		total=0;
		m_fhead->flag=PACK_ACTION;			
		m_fhead->type=m_type;	
		m_fhead->filelen=file_len;
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_MMC_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_MMC_HEAD));	

		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write eMMC head error\n")); 
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}
		
		fread(lpBuffer,m_fhead->filelen,1,fp);
		if(lpBuffer[0]!=0x5) 
		{
			AfxMessageBox(_T("This file is not pack image"));
		}
		fclose(fp);


		char *pbuf = lpBuffer;	
		PACK_HEAD *ppackhead=(PACK_HEAD *)lpBuffer;
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, sizeof(PACK_HEAD));		
		Sleep(5);
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)	return FALSE;
		if(bResult!=TRUE) return FALSE;
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}
		total+= sizeof(PACK_HEAD);
		pbuf+= sizeof(PACK_HEAD);

		PACK_CHILD_HEAD child;
		m_progress.SetRange(0,short(ppackhead->num*100));
		int posnum=0;
#if !defined(BATCH_BURN)
		for(int i=0;i<(int)(ppackhead->num);i++)
		{
			memcpy(&child,(char *)pbuf,sizeof(PACK_CHILD_HEAD));
			//Sleep(20);
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, sizeof(PACK_CHILD_HEAD));			
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)	return FALSE;
			if(bResult!=TRUE) return FALSE;
			total+= sizeof(PACK_CHILD_HEAD);
			pbuf+= sizeof(PACK_CHILD_HEAD);
			
				scnt=child.filelen/BUF_SIZE;
				rcnt=child.filelen%BUF_SIZE;				
			
				while(scnt>0)
				{		
					//Sleep(20);
					bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BUF_SIZE);					
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						fclose(fp);				
						return FALSE;
					}

					 if(bResult==TRUE)
					 {
						pbuf+=BUF_SIZE;
						total+=BUF_SIZE;

						pos=(int)(((float)(((float)total/(float)file_len))*100));
						posstr.Format(_T("%d%%"),pos);
						
						DbgOut("eMMC wait ack");
						bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
						DbgOut("eMMC wait ack end");
				
						if(bResult==FALSE)
						{
							delete []lpBuffer;
							NucUsb.NUC_CloseHandle();
							fclose(fp);
							AfxMessageBox(_T("ACK error !"));
							return FALSE;
						}

					 }

					 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					 {						
						return FALSE;
					 }

					 scnt--;

					 if(pos%5==0)
					 {
						PostMessage(WM_MMC_PROGRESS,(LPARAM)(posnum+pos),0);
					 }
				 
				}

				if(rcnt>0)
				{			
					//Sleep(20);
					bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);					
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{						
						delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						return FALSE;
					}

					//printf("upload %%.2f\r",((float)total/file_len)*100);										
					if(bResult==TRUE)
					{
						pbuf+=rcnt;
						total+=rcnt;								
						DbgOut("eMMC wait ack");
						bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);			
						DbgOut("eMMC wait ack end");

						if(bResult==FALSE)
						{
							delete []lpBuffer;
							NucUsb.NUC_CloseHandle();
							fclose(fp);
							AfxMessageBox(_T("ACK error !"));
							return FALSE;
						
						}

					}

					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						//fclose(fp);
						return FALSE;
					}

					pos=(int)(((float)(((float)total/(float)file_len))*100));

					if(pos>=100)
					{
						pos=100;
					}
					posstr.Format(_T("%d%%"),pos);

					if(pos%5==0)
					{
					
						PostMessage(WM_MMC_PROGRESS,(LPARAM)(posnum+pos),0);
					}
					
				}			
	
					

				
				//fclose(fp);
			//burn progress...
				burn_pos=0;
				//PostMessage(WM_MMC_PROGRESS,(LPARAM)0,0);
				m_progress.SetBkColor(COLOR_BURN);
				posnum+=100;
				while(burn_pos!=100)
				{
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						return FALSE;
					}

					DbgOut("eMMC wait burn ack");
					bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
					if(bResult==FALSE)
					{
						NucUsb.NUC_CloseHandle();
						AfxMessageBox(_T("ACK error !"));
						return FALSE;
					}
					DbgOut("eMMC wait burn ack end");
					if(!((ack>>16)&0xffff))
					{
						burn_pos=(UCHAR)(ack&0xffff);
						PostMessage(WM_MMC_PROGRESS,(LPARAM)(posnum+burn_pos),0);
					}
					else
					{
						NucUsb.NUC_CloseHandle();
						AfxMessageBox(_T("Burn error"));
						return FALSE;
					}						
				}	
				posnum+=100;
		}
#else
        unsigned int blockNum;
		int prepos=0;
		for(int i=0;i<(int)(ppackhead->num);i++)
		{
			memcpy(&child,(char *)pbuf,sizeof(PACK_CHILD_HEAD));			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, sizeof(PACK_CHILD_HEAD));						
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)	return FALSE;
			if(bResult!=TRUE) return FALSE;

			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
			if(bResult==FALSE)
			{
				NucUsb.NUC_CloseHandle();
				return FALSE;
			}
			//total+= sizeof(PACK_CHILD_HEAD);
			pbuf+= sizeof(PACK_CHILD_HEAD);
			//Sleep(1);
				scnt=child.filelen/BUF_SIZE;
				rcnt=child.filelen%BUF_SIZE;				
				total=0;
				while(scnt>0)
				{		
					//Sleep(20);
					bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BUF_SIZE);					
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						fclose(fp);				
						return FALSE;
					}

					 if(bResult==TRUE)
					 {
						pbuf+=BUF_SIZE;
						total+=BUF_SIZE;

						pos=(int)(((float)(((float)total/(float)child.filelen))*100));
						posstr.Format(_T("%d%%"),pos);
						
						DbgOut("eMMC wait ack");
						bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
						DbgOut("eMMC wait ack end");
				
						if(bResult==FALSE)
						{
							delete []lpBuffer;
							NucUsb.NUC_CloseHandle();
							fclose(fp);
							CString tmp;
							tmp.Format(_T("ACK error %d!"),i);
							AfxMessageBox(tmp);
							return FALSE;
						}

					 }

					 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					 {						
						return FALSE;
					 }

					 scnt--;

					 if((pos!=prepos) || (pos==100))
					 {				
					    prepos=pos;
						PostMessage(WM_MMC_PROGRESS,(LPARAM)(posnum+pos),0);
					 }
				 
				}

				if(rcnt>0)
				{			
					//Sleep(20);
					bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);					
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{						
						delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						return FALSE;
					}

					//printf("upload %%.2f\r",((float)total/file_len)*100);										
					if(bResult==TRUE)
					{
						pbuf+=rcnt;
						total+=rcnt;								
						DbgOut("NAND wait ack");
						bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
						DbgOut("NAND wait ack end");

						if(bResult==FALSE)
						{
							delete []lpBuffer;
							NucUsb.NUC_CloseHandle();
							fclose(fp);
							CString tmp;
							tmp.Format(_T("ACK error(rcnt>0) %d!"),i);
							AfxMessageBox(tmp);
							return FALSE;
						
						}

					}

					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						//fclose(fp);
						return FALSE;
					}

					pos=(int)(((float)(((float)total/(float)child.filelen))*100));

					if(pos>=100)
					{
						pos=100;
					}
					posstr.Format(_T("%d%%"),pos);

					if((pos!=prepos)||pos==100)
					{
					    prepos=pos;
						PostMessage(WM_MMC_PROGRESS,(LPARAM)(posnum+pos),0);
					}
					
				}	
                posnum+=100;

				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&blockNum,4);
				if(bResult==FALSE)
				{
						NucUsb.NUC_CloseHandle();
						AfxMessageBox(_T("read block error !"));
						return FALSE;
				}	
		}//for(int i=0;i<(int)(ppackhead->num);i++)
#endif
	delete []lpBuffer;
	NucUsb.NUC_CloseHandle();
	return TRUE;

}

BOOL CMMCDlg::XUSB_Burn(CString& portName,CString& m_pathName,int *len)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	FILE* fp;
	int pos=0;
	UCHAR burn_pos=0;
	unsigned int total,file_len,scnt,rcnt;
	ULONG ack;
	//NORBOOT_NAND_HEAD fhead;
	char* lpBuffer;
	unsigned char *ddrbuf;
	int ddrlen;	
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
    m_progress.SetRange(0,100);
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack=0x0;
		bResult=NucUsb.NUC_SetType(0,MMC,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}
	
		
		fp=_wfopen(m_pathName,_T("rb"));
  
		if(!fp)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}

		fseek(fp,0,SEEK_END);
		file_len=ftell(fp);
		fseek(fp,0,SEEK_SET);

		if(!file_len)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}
		
		
		memset((unsigned char*)m_fhead,0,sizeof(NORBOOT_MMC_HEAD));
		
		m_fhead->flag=WRITE_ACTION;
		((NORBOOT_MMC_HEAD *)m_fhead)->initSize=0;

		//check AES------------------------------		
		if(m_mmc_enc_check.GetCheck()==TRUE)
			file_len=((file_len+15)/16)*16;		
		m_fhead->filelen=file_len;
#if 1
		switch(m_type)
		{
			case DATA:			
			case PACK:
				swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				*len=file_len;
				lpBuffer = new char[file_len]; //read file to buffer
				memset(lpBuffer,0xff,file_len);					
				((NORBOOT_MMC_HEAD *)m_fhead)->macaddr[7]=0;								
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);
				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_MMC_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_MMC_HEAD));
			break;
			case ENV:
				swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				if(file_len>(0x10000-4))
				{
					//delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("The environment file size is less then 64KB\n"));
					return FALSE;
				}				
				lpBuffer = new char[0x10000]; //read file to buffer
				memset(lpBuffer,0x00,0x10000);		
			
				((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;
								
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);
				m_fhead->filelen=0x10000;
				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_MMC_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_MMC_HEAD));
			break;
			case UBOOT:
				swscanf_s(_T("1"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				//-------------------DDR---------------------						
				ddrbuf=DDR2Buf(mainWnd->DDRBuf,mainWnd->DDRLen,&ddrlen);
				file_len=file_len+ddrlen;
				((NORBOOT_MMC_HEAD *)m_fhead)->initSize=ddrlen;				
				//-------------------------------------------
				*len=file_len;
				lpBuffer = new char[file_len]; //read file to buffer
				memset(lpBuffer,0xff,file_len);						
					((NORBOOT_MMC_HEAD *)m_fhead)->macaddr[7]=0;
				
				
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);

				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_MMC_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_MMC_HEAD));
			break;
		}
#else
		if(m_type!=UBOOT)
		{
			swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
			swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
			swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
			*len=file_len;
		}else
		{	
			swscanf_s(_T("1"),_T("%d"),&m_fhead->no);
			swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
			swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
			//-------------------DDR---------------------						
			ddrbuf=DDR2Buf(mainWnd->DDRBuf,mainWnd->DDRLen,&ddrlen);
			file_len=file_len+ddrlen;
			((NORBOOT_MMC_HEAD *)m_fhead)->initSize=ddrlen;				
			//-------------------------------------------
			*len=file_len;
		}

		lpBuffer = new char[file_len]; //read file to buffer
		memset(lpBuffer,0x00,file_len);		
		CString mactmp;						
		((NORBOOT_MMC_HEAD *)m_fhead)->macaddr[7]=0;
		

	//	for(int i=0;i<6;i++)
	//	  ((NORBOOT_NAND_HEAD2 *)m_fhead)->macaddr[i]=i*10;


		wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);

		m_fhead->type=m_type;			
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_MMC_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_MMC_HEAD));	
#endif
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write eMMC head error\n")); 
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}
#if 1
		switch(m_type)
		{
			case DATA:
				if(m_mmc_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer,m_fhead->filelen,1,fp);
				else{
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);					
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					if(encbuf!=NULL)
					{
						free(encbuf);
						encbuf=NULL;
					}
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&enclen);
					if(encbuf==NULL) 
					{
						if(lpBuffer!=NULL) delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						fclose(fp);
						AfxMessageBox(_T("AES encrpt failed or AES value equal to zero"));
						return FALSE;
					}
					memcpy(lpBuffer,encbuf,enclen);	
				}
			break;
			case PACK:
				fread(lpBuffer,m_fhead->filelen,1,fp);				
			break;
			case ENV:
				#if 0
				fread(lpBuffer+4,file_len,1,fp);
				#else
				{
					char line[256];
					char* ptr=(char *)(lpBuffer+4);
					while (1) {
						 if (fgets(line,256, fp) == NULL) break;
						 if(line[strlen(line)-2]==0x0D || line[strlen(line)-1]==0x0A)
						 {
							strncpy(ptr,line,strlen(line)-1);
							ptr[strlen(line)-2]=0x0;
							ptr+=(strlen(line)-1);
						 }else{
							 strncpy(ptr,line,strlen(line));
							 ptr+=(strlen(line));
						 }
					}
				
				}
				#endif
				
				*(unsigned int *)lpBuffer=mainWnd->CalculateCRC32((unsigned char *)(lpBuffer+4),0x10000-4);
				*len=file_len=0x10000;					
				if(mainWnd->envbuf!=NULL) free(mainWnd->envbuf);
				mainWnd->envbuf=(unsigned char *)malloc(0x10000);
				memcpy(mainWnd->envbuf,lpBuffer,0x10000);
			break;
			case UBOOT:
				memcpy(lpBuffer,ddrbuf,ddrlen);			
				//------AES--------------------------------------------
				if(m_mmc_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer+ddrlen,m_fhead->filelen,1,fp);
				else{
					char *encbuf;
					unsigned int len;
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);					
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&len);
					if(encbuf==NULL) 
					{
						if(lpBuffer!=NULL) delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						fclose(fp);
						AfxMessageBox(_T("AES encrpt failed or AES value equal to zero"));
						return FALSE;
					}
					memcpy(lpBuffer+ddrlen,encbuf,len);	
				}
				break;
		}
#else
		if(m_type==UBOOT){
				memcpy(lpBuffer,ddrbuf,ddrlen);			
				//------AES--------------------------------------------
				if(m_mmc_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer+ddrlen,m_fhead->filelen,1,fp);
				else{
					char *encbuf;
					unsigned int len;
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&len);
					memcpy(lpBuffer+ddrlen,encbuf,len);				
				}
				//-----------------------------------------------------
		}else{
			fread(lpBuffer,m_fhead->filelen,1,fp);
		}
#endif
		scnt=file_len/BUF_SIZE;
		rcnt=file_len%BUF_SIZE;

#if !defined(BATCH_BURN)
		total=0;
		char *pbuf = lpBuffer;	
		while(scnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BUF_SIZE);
			pbuf+=BUF_SIZE;
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);				
				return FALSE;
			}

			 if(bResult==TRUE)
			 {
				total+=BUF_SIZE;

				pos=(int)(((float)(((float)total/(float)file_len))*100));
				posstr.Format(_T("%d%%"),pos);
				
				DbgOut("eMMC wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
				DbgOut("eMMC wait ack end");
		
				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				}

			 }

			 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			 {
				fclose(fp);
				return FALSE;
			 }

			 scnt--;

			 if(pos%5==0)
			 {
				PostMessage(WM_MMC_PROGRESS,(LPARAM)pos,0);
			 }
		 
		}

		if(rcnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				return FALSE;
			}

			//printf("upload %%.2f\r",((float)total/file_len)*100);
			
			
			if(bResult==TRUE)
			{
				total+=rcnt;								
				DbgOut("eMMC wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);			
				DbgOut("eMMC wait ack end");

				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				
				}

			}

			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				return FALSE;
			}

			pos=(int)(((float)(((float)total/(float)file_len))*100));

			if(pos>=100)
			{
				pos=100;
			}
			posstr.Format(_T("%d%%"),pos);

			if(pos%5==0)
			{
			
				PostMessage(WM_MMC_PROGRESS,(LPARAM)pos,0);
			}
			
		}

	delete []lpBuffer;
	fclose(fp);
//burn progress...
	burn_pos=0;
	PostMessage(WM_MMC_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_BURN);
	
	while(burn_pos!=100)
	{
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			return FALSE;
		}

		DbgOut("eMMC wait burn ack");
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}
		DbgOut("eMMC wait burn ack end");
		if(!((ack>>16)&0xffff))
		{
			burn_pos=(UCHAR)(ack&0xffff);
			PostMessage(WM_MMC_PROGRESS,(LPARAM)burn_pos,0);
		}
		else
		{
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("Burn error"));
			return FALSE;
		}

	}
#else
		total=0;
		char *pbuf = lpBuffer;	
		int prepos=0;
		while(scnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BUF_SIZE);
			pbuf+=BUF_SIZE;
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);				
				return FALSE;
			}

			 if(bResult==TRUE)
			 {
				total+=BUF_SIZE;

				pos=(int)(((float)(((float)total/(float)file_len))*100));
				posstr.Format(_T("%d%%"),pos);
				
				DbgOut("eMMC wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
				DbgOut("eMMC wait ack end");
		
				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				}

			 }

			 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			 {
				fclose(fp);
				return FALSE;
			 }

			 scnt--;

			 if((pos!=prepos) || pos==100)
			 {
				prepos=pos;
				PostMessage(WM_MMC_PROGRESS,(LPARAM)pos,0);
			 }
		 
		}

		if(rcnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				return FALSE;
			}

			//printf("upload %%.2f\r",((float)total/file_len)*100);
			
			
			if(bResult==TRUE)
			{
				total+=rcnt;								
				DbgOut("eMMC wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);			
				DbgOut("eMMC wait ack end");

				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				
				}

			}

			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				return FALSE;
			}

			pos=(int)(((float)(((float)total/(float)file_len))*100));

			if(pos>=100)
			{
				pos=100;
			}
			posstr.Format(_T("%d%%"),pos);

			if(pos%5==0)
			{
			
				PostMessage(WM_MMC_PROGRESS,(LPARAM)pos,0);
			}
			
		}

	delete []lpBuffer;
	fclose(fp);

	unsigned int blockNum;
	bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&blockNum,4);
	if(bResult==FALSE)
	{
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("read block error !"));
			return FALSE;
	}	
#endif
	NucUsb.NUC_CloseHandle();
	return TRUE;
}

BOOL CMMCDlg::XUSB_Verify(CString& portName,CString& m_pathName)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;	
	FILE* fp;
	int pos=0;	
	unsigned int total=0,file_len,scnt,rcnt,ack;
	char* lpBuffer;
	char temp[BUF_SIZE];
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
	PostMessage(WM_MMC_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_VERIFY);

	/***********************************************/
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack;
		bResult=NucUsb.NUC_SetType(0,MMC,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];
		fp=_wfopen(m_pathName,_T("rb"));

		if(!fp)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}
		if(m_type!=ENV){
			if(m_mmc_enc_check.GetCheck()!=TRUE)
			{
				fseek(fp,0,SEEK_END);
				file_len=ftell(fp);
				fseek(fp,0,SEEK_SET);
			}else
				file_len=enclen;
		}else
			file_len=0x10000;

		if(!file_len)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}
		
		m_fhead->flag=VERIFY_ACTION;		
		
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_MMC_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_MMC_HEAD));					
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write SPI head error\n"));
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}
		
		scnt=(file_len)/BUF_SIZE;
		rcnt=(file_len)%BUF_SIZE;

		total=0;
		int propos=0;
		while(scnt>0)
		{			
			if(m_type!=ENV)
			{
				if(m_mmc_enc_check.GetCheck()!=TRUE)				
					fread(temp,BUF_SIZE,1,fp);
				else{
					memcpy(temp,encbuf+total,BUF_SIZE);
				}
			}
			else{
				memcpy(temp,mainWnd->envbuf+total,BUF_SIZE);
			}
			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer, BUF_SIZE);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}

			if(bResult==TRUE)
			 {

				total+=BUF_SIZE;

				pos=(int)(((float)(((float)total/(float)file_len))*100));
				posstr.Format(_T("%d%%"),pos);

				if(DataCompare(temp,lpBuffer,BUF_SIZE))
					ack=BUF_SIZE;
				else
					ack=0;//compare error				
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);		
				if((bResult==FALSE)||(!ack))
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					return FALSE;
				}

			 }
			 else
			 {
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				fclose(fp);
				return FALSE;
			 }

			 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			 {
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			 }

			 scnt--;

			 if(pos!=propos || pos==100)
			 {
				propos=pos;
				PostMessage(WM_MMC_PROGRESS,(LPARAM)pos,0);
			 }

			 
		}

		if(rcnt>0)
		{			
			if(m_type!=ENV)
			{
				if(m_mmc_enc_check.GetCheck()!=TRUE)				
					fread(temp,rcnt,1,fp);
				else{
					memcpy(temp,encbuf+total,rcnt);
				}
			}
			else{
				memcpy(temp,mainWnd->envbuf+total,rcnt);
			}
			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}
			
			if(bResult==TRUE)
			{
				total+=rcnt;
				if(DataCompare(temp,lpBuffer,rcnt))
					ack=BUF_SIZE;
				else
					ack=0;//compare error				
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack, 4);
				if((bResult==FALSE)||(!ack))
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					return FALSE;
				
				}

			}
			 else
			 {
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();	
				fclose(fp);
				return FALSE;
			 }

			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}

			pos=(int)(((float)(((float)total/(float)file_len))*100));

			if(pos>=100)
			{
				pos=100;
			}
			posstr.Format(_T("%d%%"),pos);

			if(pos%5==0)
			{
				PostMessage(WM_MMC_PROGRESS,(LPARAM)pos,0);
			}
			
		}

	delete []lpBuffer;
	fclose(fp);
	NucUsb.NUC_CloseHandle();
	return TRUE;

}
BOOL CMMCDlg::XUSB_Read(CString& portName,CString& m_pathName,unsigned int addr,unsigned int len)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	int pos=0;
	//NORBOOT_NAND_HEAD fhead;
	unsigned int total=0,scnt,rcnt,ack;
	char* lpBuffer;
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
	PostMessage(WM_MMC_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_VERIFY);

	/***********************************************/
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack;
		bResult=NucUsb.NUC_SetType(0,MMC,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];
		FILE* tempfp;
		//-----------------------------------			
		tempfp=_wfopen(m_pathName,_T("w+b"));
		//-----------------------------------	
		if(!tempfp)
		{
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}	

		m_fhead->flag=READ_ACTION;		
		m_fhead->flashoffset=addr;
		m_fhead->filelen=len;
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_MMC_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_MMC_HEAD));

		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("Write SPI head error\n"));
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}

	scnt=len/BUF_SIZE;
	rcnt=len%BUF_SIZE;
	total=0;
	int prepos=0;
	while(scnt>0)
	{		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{		
			total+=BUF_SIZE;
			pos=(int)(((float)(((float)total/(float)len))*100));				
			posstr.Format(_T("%d%%"),pos);	
			fwrite(lpBuffer,BUF_SIZE,1,tempfp);			
			ack=BUF_SIZE;			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);			
			if(bResult==FALSE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();				
				return FALSE;
			}			
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			return FALSE;
		}
		
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}		
		
		scnt--;
 		if((pos!=prepos) || pos==100 )
		{
			prepos=pos;
			PostMessage(WM_MMC_PROGRESS,(LPARAM)pos,0);
		}
	}
	
	if(rcnt>0)
	{			 		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);			
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{
			total+=rcnt;
			fwrite(lpBuffer,rcnt,1,tempfp);			
			ack=BUF_SIZE;		
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);
			if(bResult!=TRUE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();			
				return FALSE;
			}
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();		
			return FALSE;	
		}
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;		
			return FALSE;
		}	
		pos=(int)(((float)(((float)total/(float)len))*100));
		if(pos>=100)
		{
			pos=100;
		}	
		posstr.Format(_T("%d%%"),pos);
		if((pos!=prepos) || (pos==100))
		{
			PostMessage(WM_MMC_PROGRESS,(LPARAM)pos,0);
		}	
	}
	delete []lpBuffer;	
	NucUsb.NUC_CloseHandle();
	fclose(tempfp);	
	/********************************************/		
	return TRUE;
}
BOOL CMMCDlg::XUSB_Format(CString& portName)
{
	BOOL bResult;
	CString tempstr;
	int count=0;
	unsigned int ack,format_pos=0;
	NORBOOT_MMC_HEAD *fhead;
	char* lpBuffer;
	fhead=(NORBOOT_MMC_HEAD *)malloc(sizeof(NORBOOT_MMC_HEAD));

	/***********************************************/
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}

		USHORT typeack;
		bResult=NucUsb.NUC_SetType(0,MMC,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];
		memset((unsigned char*)fhead,0,sizeof(NORBOOT_MMC_HEAD));
		fhead->flag=FORMAT_ACTION;
		swscanf_s(m_space,_T("%d"),&fhead->ReserveSize);		

		memcpy(lpBuffer,(unsigned char*)fhead,sizeof(NORBOOT_MMC_HEAD));
		free(fhead);

		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_MMC_HEAD));
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			AfxMessageBox(_T("Write eMMC head error\n"));
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}

		format_pos=0;
		int wait_pos=0;
		while(format_pos!=100)
		{
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				return FALSE;
			}

			DbgOut("eMMC wait erase ack");
			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
			if(bResult=FALSE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				AfxMessageBox(_T("ACK error !"));
				return FALSE;
			}
			DbgOut("eMMC wait erase ack end");
			if(!((ack>>16)&0xffff))
			{
				format_pos=ack&0xffff;
				PostMessage(WM_MMC_PROGRESS,(LPARAM)format_pos,0);
			}
			else
			{
				
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				CString msg;
				msg.Format(_T("Format error ack=0x%08x\n"),ack);
				AfxMessageBox(msg);
				return FALSE;
			}

			if(format_pos==95)
			{
				wait_pos++;
				if(wait_pos>100)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					AfxMessageBox(_T("Format error"));
					return FALSE;
				}
					
			}

		}

	
	delete []lpBuffer;
	NucUsb.NUC_CloseHandle();
	return TRUE;
}

/************** MMC End ************/

/************** MMC End ************/

/************** NAND Begin ************/
BOOL CNANDDlg::XUSB_Pack(CString& portName,CString& m_pathName,int *len)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	FILE* fp;
	int pos=0;
	UCHAR burn_pos=0;
	unsigned int total,file_len,scnt,rcnt;
	ULONG ack;
	//NORBOOT_NAND_HEAD fhead;
	char* lpBuffer;
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);

		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack=0x0;
		bResult=NucUsb.NUC_SetType(0,NAND,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}
	
		
		fp=_wfopen(m_pathName,_T("rb"));
  
		if(!fp)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}

		fseek(fp,0,SEEK_END);
		file_len=ftell(fp);
		fseek(fp,0,SEEK_SET);

		if(!file_len)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}

		unsigned int magic;
		fread((unsigned char *)&magic,4,1,fp);
		if(magic!=0x5)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Pack Image Format Error\n"));
			return FALSE;
		}
		fseek(fp,0,SEEK_SET);
		
		lpBuffer = new char[file_len]; //read file to buffer
		memset(lpBuffer,0x00,file_len);		

		memset((unsigned char*)m_fhead,0,sizeof(NORBOOT_NAND_HEAD));
		total=0;
		m_fhead->flag=PACK_ACTION;			
		m_fhead->type=m_type;	
		m_fhead->filelen=file_len;
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));	

		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write NAND head error\n")); 
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}
		
		fread(lpBuffer,m_fhead->filelen,1,fp);
		if(lpBuffer[0]!=0x5) 
		{
			AfxMessageBox(_T("This file is not pack image"));
		}
		fclose(fp);


		char *pbuf = lpBuffer;	
		PACK_HEAD *ppackhead=(PACK_HEAD *)lpBuffer;
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, sizeof(PACK_HEAD));		
		Sleep(5);
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)	return FALSE;
		if(bResult!=TRUE) return FALSE;
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}
		total+= sizeof(PACK_HEAD);
		pbuf+= sizeof(PACK_HEAD);

		PACK_CHILD_HEAD child;	
		m_progress.SetRange(0,short(ppackhead->num*100));
		int posnum=0;
		int prepos=0;
#if !defined(BATCH_BURN)
		for(int i=0;i<(int)(ppackhead->num);i++)
		{
			memcpy(&child,(char *)pbuf,sizeof(PACK_CHILD_HEAD));			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, sizeof(PACK_CHILD_HEAD));			
			
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)	return FALSE;
			if(bResult!=TRUE) return FALSE;
			total+= sizeof(PACK_CHILD_HEAD);
			pbuf+= sizeof(PACK_CHILD_HEAD);
			//Sleep(1);
				scnt=child.filelen/BUF_SIZE;
				rcnt=child.filelen%BUF_SIZE;				
			
				while(scnt>0)
				{		
					//Sleep(20);
					bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BUF_SIZE);					
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						fclose(fp);				
						return FALSE;
					}

					 if(bResult==TRUE)
					 {
						pbuf+=BUF_SIZE;
						total+=BUF_SIZE;

						pos=(int)(((float)(((float)total/(float)file_len))*100));
						posstr.Format(_T("%d%%"),pos);
						
						DbgOut("SPI wait ack");
						bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
						DbgOut("SPI wait ack end");
				
						if(bResult==FALSE)
						{
							delete []lpBuffer;
							NucUsb.NUC_CloseHandle();
							fclose(fp);
							AfxMessageBox(_T("ACK error !"));
							return FALSE;
						}

					 }

					 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					 {						
						return FALSE;
					 }

					 scnt--;

					 if(pos%5==0)
					 {					    
						PostMessage(WM_NAND_PROGRESS,(LPARAM)(posnum+pos),0);
					 }
				 
				}

				if(rcnt>0)
				{			
					//Sleep(20);
					bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);					
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{						
						delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						return FALSE;
					}

					//printf("upload %%.2f\r",((float)total/file_len)*100);										
					if(bResult==TRUE)
					{
						pbuf+=rcnt;
						total+=rcnt;								
						DbgOut("NAND wait ack");
						bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);			
						DbgOut("NAND wait ack end");

						if(bResult==FALSE)
						{
							delete []lpBuffer;
							NucUsb.NUC_CloseHandle();
							fclose(fp);
							AfxMessageBox(_T("ACK error !"));
							return FALSE;
						
						}

					}

					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						//fclose(fp);
						return FALSE;
					}

					pos=(int)(((float)(((float)total/(float)file_len))*100));

					if(pos>=100)
					{
						pos=100;
					}
					posstr.Format(_T("%d%%"),pos);

					if(pos%5==0)
					{
					
						PostMessage(WM_NAND_PROGRESS,(LPARAM)(posnum+pos),0);
					}
					
				}			
	
					
				posnum+=100;
				
				//fclose(fp);
			//burn progress...
				burn_pos=0;
				//PostMessage(WM_NAND_PROGRESS,(LPARAM)0,0);
				m_progress.SetBkColor(COLOR_BURN);
				
				while(burn_pos!=100)
				{
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						return FALSE;
					}

					DbgOut("NAND wait burn ack");
					bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
					if(bResult==FALSE)
					{
						NucUsb.NUC_CloseHandle();
						AfxMessageBox(_T("ACK error !"));
						return FALSE;
					}
					DbgOut("NAND wait burn ack end");
					if(!((ack>>16)&0xffff))
					{
						burn_pos=(UCHAR)(ack&0xffff);
						PostMessage(WM_NAND_PROGRESS,(LPARAM)(posnum+burn_pos),0);
					}
					else
					{
						NucUsb.NUC_CloseHandle();
						AfxMessageBox(_T("Burn error"));
						return FALSE;
					}						
				}	
				posnum+=100;
		}
#else
        unsigned int blockNum;
		for(int i=0;i<(int)(ppackhead->num);i++)
		{
			total=0;
			memcpy(&child,(char *)pbuf,sizeof(PACK_CHILD_HEAD));			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, sizeof(PACK_CHILD_HEAD));						
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)	return FALSE;
			if(bResult!=TRUE) return FALSE;

			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
			if(bResult==FALSE)
			{
				NucUsb.NUC_CloseHandle();
				return FALSE;
			}
			//total+= sizeof(PACK_CHILD_HEAD);
			pbuf+= sizeof(PACK_CHILD_HEAD);
			//Sleep(1);
				scnt=child.filelen/BUF_SIZE;
				rcnt=child.filelen%BUF_SIZE;				
				total=0;
				while(scnt>0)
				{		
					//Sleep(20);
					bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BUF_SIZE);					
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						fclose(fp);				
						return FALSE;
					}

					 if(bResult==TRUE)
					 {
						pbuf+=BUF_SIZE;
						total+=BUF_SIZE;

						//pos=(int)(((float)(((float)total/(float)file_len))*100));
						pos=(int)(((float)(((float)total/(float)child.filelen))*100));
						posstr.Format(_T("%d%%"),pos);
						
						DbgOut("NAND wait ack");
						bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
						DbgOut("NAND wait ack end");
				
						if(bResult==FALSE)
						{
							delete []lpBuffer;
							NucUsb.NUC_CloseHandle();
							fclose(fp);
							CString tmp;
							tmp.Format(_T("ACK error %d!"),i);
							AfxMessageBox(tmp);
							return FALSE;
						}

					 }

					 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					 {						
						return FALSE;
					 }

					 scnt--;

					 if((pos!=prepos) || (pos==100))
					 {				
						prepos=pos;
						PostMessage(WM_NAND_PROGRESS,(LPARAM)(posnum+pos),0);
					 }
				 
				}

				if(rcnt>0)
				{			
					//Sleep(20);
					bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);					
					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{						
						delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						return FALSE;
					}

					//printf("upload %%.2f\r",((float)total/file_len)*100);										
					if(bResult==TRUE)
					{
						pbuf+=rcnt;
						total+=rcnt;								
						DbgOut("NAND wait ack");
						bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
						DbgOut("NAND wait ack end");

						if(bResult==FALSE)
						{
							delete []lpBuffer;
							NucUsb.NUC_CloseHandle();
							fclose(fp);
							CString tmp;
							tmp.Format(_T("ACK error(rcnt>0) %d!"),i);
							AfxMessageBox(tmp);
							return FALSE;
						
						}

					}

					if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
					{
						//fclose(fp);
						return FALSE;
					}

					//pos=(int)(((float)(((float)total/(float)file_len))*100));
					pos=(int)(((float)(((float)total/(float)child.filelen))*100));

					if(pos>=100)
					{
						pos=100;
					}
					posstr.Format(_T("%d%%"),pos);

					if((pos!=prepos) || (pos==100))
					{
					    prepos=pos;
						PostMessage(WM_NAND_PROGRESS,(LPARAM)(posnum+pos),0);
					}
					
				}	
                posnum+=100;

				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&blockNum,4);
				if(bResult==FALSE)
				{
						NucUsb.NUC_CloseHandle();
						AfxMessageBox(_T("read block error !"));
						return FALSE;
				}	
		}//for(int i=0;i<(int)(ppackhead->num);i++)
#endif

	delete []lpBuffer;
	NucUsb.NUC_CloseHandle();
	return TRUE;

}

BOOL CNANDDlg::XUSB_Burn(CString& portName,CString& m_pathName,int *len,int *blockNum)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	FILE* fp;
	int pos=0;
	UCHAR burn_pos=0;
	unsigned int total,file_len,scnt,rcnt;
	ULONG ack;
	//NORBOOT_NAND_HEAD fhead;
	char* lpBuffer;
	unsigned char *ddrbuf;
	int ddrlen;	
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
    m_progress.SetRange(0,100);
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack=0x0;
		bResult=NucUsb.NUC_SetType(0,NAND,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		
		fp=_wfopen(m_pathName,_T("rb"));

		if(!fp)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}
        
		
		
		fseek(fp,0,SEEK_END);
		file_len=ftell(fp);
		fseek(fp,0,SEEK_SET);

		if( (file_len>(mainWnd->m_info.Nand_uPagePerBlock*mainWnd->m_info.Nand_uPageSize))&&m_type==UBOOT)
		{
#if 1
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Uboot File length cannot greater than block size\n"));
			return FALSE;
#else
			CString tmp;
			tmp.Format(_T("Uboot File length cannot greater than block size. Do you confirm this operation ?"),4*val-1);

			if(::MessageBox(this->m_hWnd,tmp,_T("Nu Writer"),MB_OKCANCEL|MB_ICONWARNING)==IDCANCEL)
			{
				NucUsb.NUC_CloseHandle();
				fclose(fp);
				return FALSE;
			}
#endif
		}
        
		if(!file_len)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}

		memset((unsigned char*)m_fhead,0,sizeof(NORBOOT_NAND_HEAD));
		m_fhead->flag=WRITE_ACTION;
		((NORBOOT_NAND_HEAD *)m_fhead)->initSize=0;

		//check AES------------------------------		
		if(m_nand_enc_check.GetCheck()==TRUE)
			file_len=((file_len+15)/16)*16;		
		m_fhead->filelen=file_len;
#if 1
		switch(m_type)
		{
			case DATA:
			case IMAGE:
			case PACK:			
				swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				*len=file_len;
				lpBuffer = new char[file_len]; //read file to buffer
				memset(lpBuffer,0xff,file_len);					
				((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;								
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);
				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
			break;
			case ENV:
				swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				if(file_len>(0x10000-4))
				{
					//delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("The environment file size is less then 64KB\n"));
					return FALSE;
				}				
				lpBuffer = new char[0x10000]; //read file to buffer
				memset(lpBuffer,0x00,0x10000);		
			
				((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;
								
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);
				m_fhead->filelen=0x10000;
				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
			break;
			case UBOOT:
				swscanf_s(_T("1"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				//-------------------DDR---------------------						
				ddrbuf=DDR2Buf(mainWnd->DDRBuf,mainWnd->DDRLen,&ddrlen);
				file_len=file_len+ddrlen;
				((NORBOOT_NAND_HEAD *)m_fhead)->initSize=ddrlen;				
				//-------------------------------------------
				*len=file_len;
				lpBuffer = new char[file_len]; //read file to buffer
				memset(lpBuffer,0xff,file_len);						
					((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;
				
				
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);

				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
			break;
		}
#else
		if(m_type!=UBOOT)
		{
			swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
			swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
			swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
			*len=file_len;
		}else
		{
			swscanf_s(_T("1"),_T("%d"),&m_fhead->no);
			swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
			swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
			//-------------------DDR---------------------			
			ddrbuf=DDR2Buf(mainWnd->DDRBuf,mainWnd->DDRLen,&ddrlen);
			file_len=file_len+ddrlen;
			((NORBOOT_NAND_HEAD *)m_fhead)->initSize=ddrlen;				
			//-------------------------------------------
			*len=file_len;
		}
#endif				
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write NOR NAND head error\n"));
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}

#if 1
		switch(m_type)
		{
			case DATA:	
			case IMAGE:
				if(m_nand_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer,m_fhead->filelen,1,fp);
				else{
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);					
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					if(encbuf!=NULL)
					{
						free(encbuf);
						encbuf=NULL;
					}
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&enclen);
					if(encbuf==NULL) 
					{
						if(lpBuffer!=NULL) delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						fclose(fp);
						AfxMessageBox(_T("AES encrpt failed or AES value equal to zero"));
						return FALSE;
					}
					memcpy(lpBuffer,encbuf,enclen);	
				}
			break;
			case PACK:
				fread(lpBuffer,m_fhead->filelen,1,fp);				
			break;
			case ENV:
				#if 0
				fread(lpBuffer+4,file_len,1,fp);
				#else
				{
					char line[256];
					char* ptr=(char *)(lpBuffer+4);
					while (1) {
						 if (fgets(line,256, fp) == NULL) break;
						 if(line[strlen(line)-2]==0x0D || line[strlen(line)-1]==0x0A)
						 {
							strncpy(ptr,line,strlen(line)-1);
							ptr[strlen(line)-2]=0x0;
							ptr+=(strlen(line)-1);
						 }else{
							 strncpy(ptr,line,strlen(line));
							 ptr+=(strlen(line));
						 }
					}
				
				}
				#endif
				
				*(unsigned int *)lpBuffer=mainWnd->CalculateCRC32((unsigned char *)(lpBuffer+4),0x10000-4);
				*len=file_len=0x10000;				
				if(mainWnd->envbuf!=NULL) free(mainWnd->envbuf);
				mainWnd->envbuf=(unsigned char *)malloc(0x10000);
				memcpy(mainWnd->envbuf,lpBuffer,0x10000);
			break;
			case UBOOT:
				memcpy(lpBuffer,ddrbuf,ddrlen);			
				//------AES--------------------------------------------
				if(m_nand_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer+ddrlen,m_fhead->filelen,1,fp);
				else{
					char *encbuf;
					unsigned int len;
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);					
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&len);
					if(encbuf==NULL) 
					{
						if(lpBuffer!=NULL) delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						fclose(fp);
						AfxMessageBox(_T("AES encrpt failed or AES value equal to zero"));
						return FALSE;
					}
					memcpy(lpBuffer+ddrlen,encbuf,len);	
				}
				break;
		}
#else
		if(m_type==UBOOT){
				memcpy(lpBuffer,ddrbuf,ddrlen);			
				//------AES--------------------------------------------
				if(m_nand_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer+ddrlen,m_fhead->filelen,1,fp);
				else{
					char *encbuf;
					unsigned int len;
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);					
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&len);
					memcpy(lpBuffer+ddrlen,encbuf,len);				
				}
				//-----------------------------------------------------
			}else{
				fread(lpBuffer,m_fhead->filelen,1,fp);			
			}
#endif
		scnt=file_len/BUF_SIZE;
		rcnt=file_len%BUF_SIZE;

#if !defined(BATCH_BURN)
		total=0;
		char *pbuf = lpBuffer;	
		while(scnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BUF_SIZE);
			pbuf+=BUF_SIZE;
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);				
				return FALSE;
			}

			 if(bResult==TRUE)
			 {
				total+=BUF_SIZE;

				pos=(int)(((float)(((float)total/(float)file_len))*100));
				posstr.Format(_T("%d%%"),pos);
				
				DbgOut("NAND wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
				DbgOut("NAND wait ack end");
		
				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				}

			 }

			 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			 {
				fclose(fp);
				return FALSE;
			 }

			 scnt--;

			 if(pos%5==0)
			 {
				PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
			 }
		 
		}

		if(rcnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				return FALSE;
			}

			//printf("upload %%.2f\r",((float)total/file_len)*100);
			
			
			if(bResult==TRUE)
			{
				total+=rcnt;								
				DbgOut("NAND wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);			
				DbgOut("NAND wait ack end");

				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				
				}

			}

			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				return FALSE;
			}

			pos=(int)(((float)(((float)total/(float)file_len))*100));

			if(pos>=100)
			{
				pos=100;
			}
			posstr.Format(_T("%d%%"),pos);

			if(pos%5==0)
			{
			
				PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
			}
			
		}

	delete []lpBuffer;
	fclose(fp);
//burn progress...
	burn_pos=0;
	PostMessage(WM_NAND_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_BURN);
	
	while(burn_pos!=100)
	{
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			return FALSE;
		}

		DbgOut("NAND wait burn ack");
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}
		DbgOut("NAND wait burn ack end");
		if(!((ack>>16)&0xffff))
		{
			burn_pos=(UCHAR)(ack&0xffff);
			PostMessage(WM_NAND_PROGRESS,(LPARAM)burn_pos,0);
		}
		else
		{
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("Burn error"));
			return FALSE;
		}

	}

	bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)blockNum,4);
	if(bResult==FALSE)
	{
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("read block error !"));
			return FALSE;
	}
#else
		total=0;
		char *pbuf = lpBuffer;	
		while(scnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BUF_SIZE);
			pbuf+=BUF_SIZE;
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);				
				return FALSE;
			}

			 if(bResult==TRUE)
			 {
				total+=BUF_SIZE;

				pos=(int)(((float)(((float)total/(float)file_len))*100));
				posstr.Format(_T("%d%%"),pos);
				
				DbgOut("NAND wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
				DbgOut("NAND wait ack end");
		
				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				}

			 }

			 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			 {
				fclose(fp);
				return FALSE;
			 }

			 scnt--;

			 if(pos%5==0)
			 {
				PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
			 }
		 
		}

		if(rcnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				return FALSE;
			}

			//printf("upload %%.2f\r",((float)total/file_len)*100);
			
			
			if(bResult==TRUE)
			{
				total+=rcnt;								
				DbgOut("NAND wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);			
				DbgOut("NAND wait ack end");

				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				
				}

			}

			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				return FALSE;
			}

			pos=(int)(((float)(((float)total/(float)file_len))*100));

			if(pos>=100)
			{
				pos=100;
			}
			posstr.Format(_T("%d%%"),pos);

			if(pos%5==0)
			{
			
				PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
			}
			
		}
	delete []lpBuffer;
	fclose(fp);

	bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)blockNum,4);
	if(bResult==FALSE)
	{
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("read block error !"));
			return FALSE;
	}	
#endif
	NucUsb.NUC_CloseHandle();
	return TRUE;
}

BOOL CNANDDlg::XUSB_BurnWithOOB(CString& portName,CString& m_pathName,int *len,int *blockNum)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	FILE* fp;
	int pos=0;
	UCHAR burn_pos=0;
	unsigned int total,file_len,scnt,rcnt;
	ULONG ack;
	//NORBOOT_NAND_HEAD fhead;
	char* lpBuffer;
	unsigned char *ddrbuf;
	int ddrlen;	
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
    m_progress.SetRange(0,100);
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack=0x0;
		bResult=NucUsb.NUC_SetType(0,NAND,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		
		fp=_wfopen(m_pathName,_T("rb"));

		if(!fp)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}
        
		
		
		fseek(fp,0,SEEK_END);
		file_len=ftell(fp);
		fseek(fp,0,SEEK_SET);

		if(file_len%(mainWnd->m_info.Nand_uPageSize+mainWnd->m_info.Nand_uSpareSize)!=0)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is not Multiple of page+spare size \n"));
			return FALSE;
		}
        
		if(!file_len)
		{
			//delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}

		memset((unsigned char*)m_fhead,0,sizeof(NORBOOT_NAND_HEAD));
		m_fhead->flag=WRITE_ACTION;
		((NORBOOT_NAND_HEAD *)m_fhead)->initSize=0;

		//check AES------------------------------		
		if(m_nand_enc_check.GetCheck()==TRUE)
			file_len=((file_len+15)/16)*16;		
		m_fhead->filelen=file_len;

		switch(m_type)
		{
			case DATA:
			case IMAGE:
			case PACK:			
				swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				*len=file_len;
				lpBuffer = new char[file_len]; //read file to buffer
				memset(lpBuffer,0xff,file_len);					
				((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;								
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);
				m_fhead->type=DATA_OOB;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
			break;
			case ENV:
				swscanf_s(_T("0"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				if(file_len>(0x10000-4))
				{
					//delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("The environment file size is less then 64KB\n"));
					return FALSE;
				}				
				lpBuffer = new char[0x10000]; //read file to buffer
				memset(lpBuffer,0x00,0x10000);		
			
				((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;
								
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);
				m_fhead->filelen=0x10000;
				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
			break;
			case UBOOT:
				swscanf_s(_T("1"),_T("%d"),&m_fhead->no);
				swscanf_s(m_execaddr,_T("%x"),&m_fhead->execaddr);
				swscanf_s(m_startblock,_T("%x"),&m_fhead->flashoffset);
				//-------------------DDR---------------------						
				ddrbuf=DDR2Buf(mainWnd->DDRBuf,mainWnd->DDRLen,&ddrlen);
				file_len=file_len+ddrlen;
				((NORBOOT_NAND_HEAD *)m_fhead)->initSize=ddrlen;				
				//-------------------------------------------
				*len=file_len;
				lpBuffer = new char[file_len]; //read file to buffer
				memset(lpBuffer,0xff,file_len);						
					((NORBOOT_NAND_HEAD *)m_fhead)->macaddr[7]=0;
				
				
				wcstombs( m_fhead->name, (wchar_t *)m_imagename.GetBuffer(), 16);

				m_fhead->type=m_type;
				memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
			break;
		}
				
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write NOR NAND head error\n"));
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}


		switch(m_type)
		{
			case DATA:	
			case IMAGE:
				if(m_nand_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer,m_fhead->filelen,1,fp);
				else{
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);					
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					if(encbuf!=NULL)
					{
						free(encbuf);
						encbuf=NULL;
					}
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&enclen);
					if(encbuf==NULL) 
					{
						if(lpBuffer!=NULL) delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						fclose(fp);
						AfxMessageBox(_T("AES encrpt failed or AES value equal to zero"));
						return FALSE;
					}
					memcpy(lpBuffer,encbuf,enclen);	
				}
			break;
			case PACK:
				fread(lpBuffer,m_fhead->filelen,1,fp);				
			break;
			case ENV:
				#if 0
				fread(lpBuffer+4,file_len,1,fp);
				#else
				{
					char line[256];
					char* ptr=(char *)(lpBuffer+4);
					while (1) {
						 if (fgets(line,256, fp) == NULL) break;
						 if(line[strlen(line)-2]==0x0D || line[strlen(line)-1]==0x0A)
						 {
							strncpy(ptr,line,strlen(line)-1);
							ptr[strlen(line)-2]=0x0;
							ptr+=(strlen(line)-1);
						 }else{
							 strncpy(ptr,line,strlen(line));
							 ptr+=(strlen(line));
						 }
					}
				
				}
				#endif
				
				*(unsigned int *)lpBuffer=mainWnd->CalculateCRC32((unsigned char *)(lpBuffer+4),0x10000-4);
				*len=file_len=0x10000;				
				if(mainWnd->envbuf!=NULL) free(mainWnd->envbuf);
				mainWnd->envbuf=(unsigned char *)malloc(0x10000);
				memcpy(mainWnd->envbuf,lpBuffer,0x10000);
			break;
			case UBOOT:
				memcpy(lpBuffer,ddrbuf,ddrlen);			
				//------AES--------------------------------------------
				if(m_nand_enc_check.GetCheck()!=TRUE)			
					fread(lpBuffer+ddrlen,m_fhead->filelen,1,fp);
				else{
					char *encbuf;
					unsigned int len;
					CString szDirForKEY,KeyName;
					mainWnd->GetExeDir(szDirForKEY);
					szDirForKEY=szDirForKEY+_T("key_cfg\\");
					fclose(fp);					
					m_combo_encrypt.GetLBText(m_combo_encrypt.GetCurSel(),KeyName);
					szDirForKEY=szDirForKEY+KeyName;
					encbuf=mainWnd->AES_Encrpt(szDirForKEY,m_pathName,&len);
					if(encbuf==NULL) 
					{
						if(lpBuffer!=NULL) delete []lpBuffer;
						NucUsb.NUC_CloseHandle();
						fclose(fp);
						AfxMessageBox(_T("AES encrpt failed or AES value equal to zero"));
						return FALSE;
					}
					memcpy(lpBuffer+ddrlen,encbuf,len);	
				}
				break;
		}

		int BurnBufLen=(mainWnd->m_info.Nand_uPageSize+mainWnd->m_info.Nand_uSpareSize);
		scnt=file_len/BurnBufLen;
		rcnt=file_len%BurnBufLen;

		if(rcnt!=0){
			AfxMessageBox(_T("File length error"));
			return 0;
		}

		total=0;
		char *pbuf = lpBuffer;	
		while(scnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf, BurnBufLen);
			pbuf+=BurnBufLen;
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);				
				return FALSE;
			}

			 if(bResult==TRUE)
			 {
				total+=BurnBufLen;

				pos=(int)(((float)(((float)total/(float)file_len))*100));
				posstr.Format(_T("%d%%"),pos);
				
				DbgOut("NAND wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);				
				DbgOut("NAND wait ack end");
		
				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				}

			 }

			 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			 {
				fclose(fp);
				return FALSE;
			 }

			 scnt--;

			 if(pos%5==0)
			 {
				PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
			 }
		 
		}

		if(rcnt>0)
		{			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)pbuf,rcnt);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				return FALSE;
			}

			//printf("upload %%.2f\r",((float)total/file_len)*100);
			
			
			if(bResult==TRUE)
			{
				total+=rcnt;								
				DbgOut("NAND wait ack");
				bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);			
				DbgOut("NAND wait ack end");

				if(bResult==FALSE)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					AfxMessageBox(_T("ACK error !"));
					return FALSE;
				
				}

			}

			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				fclose(fp);
				return FALSE;
			}

			pos=(int)(((float)(((float)total/(float)file_len))*100));

			if(pos>=100)
			{
				pos=100;
			}
			posstr.Format(_T("%d%%"),pos);

			if(pos%5==0)
			{
			
				PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
			}
			
		}
	delete []lpBuffer;
	fclose(fp);

	bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)blockNum,4);
	if(bResult==FALSE)
	{
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("read block error !"));
			return FALSE;
	}	

	NucUsb.NUC_CloseHandle();
	return TRUE;
}

int CNANDDlg::XUSB_Verify(CString& portName,CString& m_pathName)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	FILE* fp;
	int pos=0;
	//NORBOOT_NAND_HEAD fhead;
	unsigned int total=0,file_len,scnt,rcnt,ack;
	char* lpBuffer;
	char temp[BUF_SIZE];
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
	PostMessage(WM_NAND_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_VERIFY);

	/***********************************************/
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack;
		bResult=NucUsb.NUC_SetType(0,NAND,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];
		fp=_wfopen(m_pathName,_T("rb"));

		if(!fp)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}

		

		if(m_type!=ENV)
		{
			if(m_nand_enc_check.GetCheck()!=TRUE)
			{
				fseek(fp,0,SEEK_END);
				file_len=ftell(fp);
				fseek(fp,0,SEEK_SET);
			}else
				file_len=enclen;
		}else{
			file_len=0x10000;
		}

		if(!file_len)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("File length is zero\n"));
			return FALSE;
		}

		if(m_type==PACK)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);			
			return NAND_VERIFY_PACK_ERROR;
		}

		if(m_type==IMAGE && (file_len%512)!=0)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);			
			return NAND_VERIFY_FILESYSTEM_ERROR;
		}
 		
		m_fhead->flag=VERIFY_ACTION;		
		
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));

		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("Write NAND head error\n"));
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			fclose(fp);
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}

		scnt=file_len/BUF_SIZE;
		rcnt=file_len%BUF_SIZE;

		total=0;
		int prepos=0;
		while(scnt>0)
		{
			if(m_type!=ENV)
			{
				if(m_nand_enc_check.GetCheck()!=TRUE)
					fread(temp,BUF_SIZE,1,fp);
				else{
					memcpy(temp,encbuf+total,BUF_SIZE);
				}			
			}
			else{
				memcpy(temp,mainWnd->envbuf+total,BUF_SIZE);
			}
			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer, BUF_SIZE);			
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}

			if(bResult==TRUE)
			 {
				total+=BUF_SIZE;

				pos=(int)(((float)(((float)total/(float)file_len))*100));
				posstr.Format(_T("%d%%"),pos);

				if(DataCompare(temp,lpBuffer,BUF_SIZE))
					ack=BUF_SIZE;
				else
					ack=0;//compare error
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);		
				if((bResult==FALSE)||(!ack))
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					return FALSE;
				}

			 }
			 else
			 {
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				fclose(fp);
				return FALSE;
			 }

			 if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			 {
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			 }

			 scnt--;

			 if(pos-prepos>=5 || pos==100)
			 {
                prepos=pos;
				PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
			 }

			 
		}

		if(rcnt>0)
		{
			if(m_type!=ENV)
			{
				if(m_nand_enc_check.GetCheck()!=TRUE)				
					fread(temp,rcnt,1,fp);
				else{
					memcpy(temp,encbuf+total,rcnt);
				}
			}
			else{
				memcpy(temp,mainWnd->envbuf+total,rcnt);
			}
			
			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}
			
			if(bResult==TRUE)
			{
				total+=rcnt;
				if(DataCompare(temp,lpBuffer,rcnt))
					ack=BUF_SIZE;
				else
					ack=0;//compare error
				bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack, 4);
				if((bResult==FALSE)||(!ack))
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					fclose(fp);
					return FALSE;
				
				}

			}
			 else
			 {
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();	
				fclose(fp);
				return FALSE;
			 }

			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				fclose(fp);
				return FALSE;
			}

			pos=(int)(((float)(((float)total/(float)file_len))*100));

			if(pos>=100)
			{
				pos=100;
			}
			posstr.Format(_T("%d%%"),pos);

			if(pos-prepos>=5 || pos==100)
			{
				prepos=pos;
				PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
			}
			
		}

	delete []lpBuffer;
	fclose(fp);
	NucUsb.NUC_CloseHandle();
	return TRUE;

}

BOOL CNANDDlg::XUSB_Read_Redunancy(CString& portName,CString& m_pathName,unsigned int addr,unsigned int len)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	int pos=0;
	//NORBOOT_NAND_HEAD fhead;
	unsigned int total=0,scnt,ack;
	char* lpBuffer;
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
	PostMessage(WM_NAND_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_VERIFY);

	/***********************************************/
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack;
		bResult=NucUsb.NUC_SetType(0,NAND,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];
		FILE* tempfp;
		//-----------------------------------			
		tempfp=_wfopen(m_pathName,_T("w+b"));
		//-----------------------------------	
		if(!tempfp)
		{
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}	

		unsigned int sparesize,totalsize;
		sparesize=mainWnd->m_info.Nand_uSpareSize;
        totalsize=mainWnd->m_info.Nand_uPagePerBlock*(mainWnd->m_info.Nand_uPageSize+mainWnd->m_info.Nand_uSpareSize);
		m_fhead->flag=READ_ACTION;		
		m_fhead->flashoffset=addr;
		m_fhead->filelen=len*(totalsize);
		m_fhead->initSize=1;  //read redunancy data, good block and bad block

		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));

		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("Write NAND head error\n"));
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}
#if 1
	unsigned int alen=len*(totalsize);
	total=0;
	for(unsigned int i=0;i<len;i++)
	{
      scnt=totalsize/(mainWnd->m_info.Nand_uPageSize+mainWnd->m_info.Nand_uSpareSize);   
	  while(scnt>0)
	  {
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,mainWnd->m_info.Nand_uPageSize);
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{		
			total+=mainWnd->m_info.Nand_uPageSize;
			pos=(int)(((float)(((float)total/(float)alen))*100));				
			posstr.Format(_T("%d%%"),pos);	
			fwrite(lpBuffer,mainWnd->m_info.Nand_uPageSize,1,tempfp);			
			ack=mainWnd->m_info.Nand_uPageSize;			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);			
			if(bResult==FALSE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();				
				return FALSE;
			}			
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			return FALSE;
		}
		
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}		
		
		scnt--;
 		if(pos%5==0)
		{
			PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
		}
        //sparesize---------------------------------------------------------
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,sparesize);
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{		
			total+=sparesize;
			pos=(int)(((float)(((float)total/(float)alen))*100));				
			posstr.Format(_T("%d%%"),pos);	
			fwrite(lpBuffer,sparesize,1,tempfp);			
			ack=sparesize;			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);			
			if(bResult==FALSE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();				
				return FALSE;
			}			
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			return FALSE;
		}
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
 		if(pos%5==0)
		{
			PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
		}
	  }//while(scnt>0) end

	}
#else
	scnt=len/BUF_SIZE;
	rcnt=len%BUF_SIZE;
	total=0;
	while(scnt>0)
	{		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{		
			total+=BUF_SIZE;
			pos=(int)(((float)(((float)total/(float)len))*100));				
			posstr.Format(_T("%d%%"),pos);	
			fwrite(lpBuffer,BUF_SIZE,1,tempfp);			
			ack=BUF_SIZE;			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);			
			if(bResult==FALSE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();				
				return FALSE;
			}			
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			return FALSE;
		}
		
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}		
		
		scnt--;
 		if(pos%5==0)
		{
			PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
		}
	}
	
	if(rcnt>0)
	{			 		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);			
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{
			total+=rcnt;
			fwrite(lpBuffer,rcnt,1,tempfp);			
			ack=BUF_SIZE;		
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);
			if(bResult!=TRUE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();			
				return FALSE;
			}
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();		
			return FALSE;	
		}
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;		
			return FALSE;
		}	
		pos=(int)(((float)(((float)total/(float)len))*100));
		if(pos>=100)
		{
			pos=100;
		}	
		posstr.Format(_T("%d%%"),pos);
		if(pos%5==0)
		{
			PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
		}	
	}
#endif
	delete []lpBuffer;	
	NucUsb.NUC_CloseHandle();
	fclose(tempfp);	
	/********************************************/		
	return TRUE;
}

BOOL CNANDDlg::XUSB_Read(CString& portName,CString& m_pathName,unsigned int addr,unsigned int len)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;
	int count=0;
	int pos=0;
	//NORBOOT_NAND_HEAD fhead;
	unsigned int total=0,scnt,rcnt,ack;
	char* lpBuffer;
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
	PostMessage(WM_NAND_PROGRESS,(LPARAM)0,0);
	m_progress.SetBkColor(COLOR_VERIFY);

	/***********************************************/
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
		USHORT typeack;
		bResult=NucUsb.NUC_SetType(0,NAND,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];
		FILE* tempfp;
		//-----------------------------------			
		tempfp=_wfopen(m_pathName,_T("w+b"));
		//-----------------------------------	
		if(!tempfp)
		{
			AfxMessageBox(_T("File Open error\n"));
			return FALSE;
		}	

		m_fhead->flag=READ_ACTION;		
		m_fhead->flashoffset=addr;
		m_fhead->filelen=len;
		m_fhead->initSize=0; //read good block
		memcpy(lpBuffer,(unsigned char*)m_fhead,sizeof(NORBOOT_NAND_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));

		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("Write NAND head error\n"));
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			AfxMessageBox(_T("ACK error !"));
			return FALSE;
		}

	scnt=len/BUF_SIZE;
	rcnt=len%BUF_SIZE;
	total=0;
	while(scnt>0)
	{		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{		
			total+=BUF_SIZE;
			pos=(int)(((float)(((float)total/(float)len))*100));				
			posstr.Format(_T("%d%%"),pos);	
			fwrite(lpBuffer,BUF_SIZE,1,tempfp);			
			ack=BUF_SIZE;			
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);			
			if(bResult==FALSE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();				
				return FALSE;
			}			
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			return FALSE;
		}
		
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}		
		
		scnt--;
 		if(pos%5==0)
		{
			PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
		}
	}
	
	if(rcnt>0)
	{			 		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)lpBuffer,BUF_SIZE);			
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;			
			return FALSE;
		}
		if(bResult==TRUE)
		{
			total+=rcnt;
			fwrite(lpBuffer,rcnt,1,tempfp);			
			ack=BUF_SIZE;		
			bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)&ack,4);
			if(bResult!=TRUE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();			
				return FALSE;
			}
		}
		else
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();		
			return FALSE;	
		}
		if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
		{
			delete []lpBuffer;		
			return FALSE;
		}	
		pos=(int)(((float)(((float)total/(float)len))*100));
		if(pos>=100)
		{
			pos=100;
		}	
		posstr.Format(_T("%d%%"),pos);
		if(pos%5==0)
		{
			PostMessage(WM_NAND_PROGRESS,(LPARAM)pos,0);
		}	
	}
	delete []lpBuffer;	
	NucUsb.NUC_CloseHandle();
	fclose(tempfp);	
	/********************************************/		
	return TRUE;
}
BOOL CNANDDlg::XUSB_Erase(CString& portName)
{
	BOOL bResult;
	CString tempstr;
	int count=0;
	unsigned int ack,erase_pos=0;
	NORBOOT_NAND_HEAD *fhead;
	char* lpBuffer;
	CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);
	fhead=(NORBOOT_NAND_HEAD *)malloc(sizeof(NORBOOT_NAND_HEAD));

	m_progress.SetRange(0,100);
	/***********************************************/
		NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			free(fhead);
			return FALSE;
		}
		USHORT typeack;
		bResult=NucUsb.NUC_SetType(0,NAND,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			free(fhead);
			return FALSE;
		}

		lpBuffer = new char[BUF_SIZE];


		memset((unsigned char*)fhead,0,sizeof(NORBOOT_NAND_HEAD));
		fhead->flag=ERASE_ACTION;

		fhead->flashoffset = _wtoi(m_sblocks); //start erase block
		fhead->execaddr=_wtoi(m_blocks);  //erase block length
		fhead->type=m_erase_flag; // Decide chip erase mode or erase mode

		if(mainWnd->ChipEraseWithBad==0)
		  fhead->no=0xFFFFFFFF;//erase good block
		else
		  fhead->no=0xFFFFFFFE;//erase good block and bad block
		memcpy(lpBuffer,(unsigned char*)fhead,sizeof(NORBOOT_NAND_HEAD));
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_NAND_HEAD));
		free(fhead);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("Write NAND head error\n"));			
			return FALSE;
		}	
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();
			AfxMessageBox(_T("ACK error !"));			
			return FALSE;
		}

		erase_pos=0;
		int wait_pos=0;
		while(erase_pos!=100)
		{
			if(WaitForSingleObject(m_ExitEvent, 0) != WAIT_TIMEOUT)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				return FALSE;
			}

			DbgOut("NAND wait erase ack");
			Sleep(2);
			bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
			if(bResult=FALSE)
			{
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				AfxMessageBox(_T("ACK error !"));
				return FALSE;
			}
			DbgOut("NAND wait erase ack end");
			if(!((ack>>16)&0xffff))
			{
				erase_pos=ack&0xffff;
				PostMessage(WM_NAND_PROGRESS,(LPARAM)erase_pos,0);
			}
			else
			{
				
				delete []lpBuffer;
				NucUsb.NUC_CloseHandle();
				CString msg;
				msg.Format(_T("Erase error ack=0x%08x\n"),ack);
				AfxMessageBox(msg);
				return FALSE;
			}

			if(erase_pos==95)
			{
				wait_pos++;
				if(wait_pos>100)
				{
					delete []lpBuffer;
					NucUsb.NUC_CloseHandle();
					AfxMessageBox(_T("Erase error"));
					return FALSE;
				}
					
			}

		}

	
	delete []lpBuffer;
	NucUsb.NUC_CloseHandle();
	return TRUE;

}

/************** NAND End ************/

/************** MTP Begin ************/
#define MTP_KEY_SUCCESS			0x80
#define MTP_NO_KEY 				0x81
#define MTP_LOCK_FAILED 		0x82
#define MTP_LOCK_KEY    		0x83
#define MTP_LOCK_SUCCESS        0x84
#define MTP_ENABLE_SUCCESS 	    0x85

//#define TEST
BOOL CMTPDlg::XUSB_Burn(CString& portName,CString& m_pathName)
{
	BOOL bResult;
	CString posstr;
	CString tempstr;

	int count=0;	
	int pos=0;	
	NORBOOT_MTP_HEAD fhead;
	unsigned int ack;
	char* lpBuffer;
		
		bResult=NucUsb.EnableWinUsbDevice();
		bResult=NucUsb.NUC_CheckFw(0);
		if(bResult==FALSE) 
		{
			AfxMessageBox(_T("Please reset device and Re-connect now !!!\n"));
			return FALSE;
		}
#ifndef TEST
		USHORT typeack=0xff;
		bResult=NucUsb.NUC_SetType(0,MTP,(UCHAR *)&typeack,sizeof(typeack));
		if(bResult==FALSE) 
		{
			NucUsb.NUC_CloseHandle();
			return FALSE;
		}
#endif
		char *buf;
		int len=0;
		CNuWriterDlg* mainWnd=(CNuWriterDlg*)(AfxGetApp()->m_pMainWnd);

		memset((char *)&fhead,0x0,sizeof(NORBOOT_MTP_HEAD));

		memset(mainWnd->_FileLineBuff,0x00,LINE_BUFF_LEN);

		if(m_mtp_option==0)
		{
			buf=mainWnd->Get_OTP_KEY(m_pathName,&len);
			memcpy((char *)&fhead.KeyOTP[0],buf,len);
			fhead.KeyLen = len;
		}else{
			unsigned char data[32];
			buf=(char *)mainWnd->CalculateSHA(m_aesfilename);			
			for(int i=0;i<8;i++){
				for(int j=0;j<4;j++)
					data[i*4+j]=buf[i*4+(3-j)];
			}

			memcpy((char *)&fhead.KeyOTP[0],data,32);
			fhead.KeyLen = 32;
			CString showsha;

			showsha.Format(_T("Key:0x%08x;0x%08x;0x%08x;0x%08x;0x%08x;0x%08x;0x%08x;0x%08x"),
				           fhead.KeyOTP[0],
						   fhead.KeyOTP[1],
						   fhead.KeyOTP[2],
						   fhead.KeyOTP[3],
						   fhead.KeyOTP[4],
						   fhead.KeyOTP[5],
						   fhead.KeyOTP[6],
						   fhead.KeyOTP[7]);
			m_mtp_status.SetWindowText(showsha);
			m_mtp_status.ShowWindow(1);
		}		
		fhead.Mode = m_mtp_mode;

		if(m_mtp_mode==0)  //AES
			fhead.Option = (1<<m_mtp_option) | ((1-m_mtp_encrypt)<<2)| 0x8;
		else{ //SHA
			if(m_mtp_mode==1)
				fhead.Option = (1<<m_mtp_option) | ((1-m_mtp_encrypt)<<2)| 0x8; //USB without SHA
			else	
				fhead.Option = (1<<m_mtp_option) | ((1-m_mtp_encrypt)<<2); //USB with SHA
		}

				
		if( ((CButton*)GetDlgItem(IDC_CHECK_LOCK_ENABLE))->GetCheck() )
			fhead.Lock = 1;
		else 
			fhead.Lock = 0;
		
		lpBuffer = new char[BUF_SIZE];		
		memcpy(lpBuffer,(unsigned char*)&fhead,sizeof(NORBOOT_MTP_HEAD));		
		bResult=NucUsb.NUC_WritePipe(0,(UCHAR *)lpBuffer, sizeof(NORBOOT_MTP_HEAD));
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();		
			AfxMessageBox(_T("Write MTP head error\n"));
			return FALSE;
		}		
		bResult=NucUsb.NUC_ReadPipe(0,(UCHAR *)&ack,4);
		if(bResult==FALSE)
		{
			delete []lpBuffer;
			NucUsb.NUC_CloseHandle();			
			AfxMessageBox(_T("MTP head ack error\n"));
			return FALSE;
		}
		    	
		pos=100;		
		PostMessage(WM_MTP_PROGRESS,(LPARAM)pos,0);
		

	delete []lpBuffer;
	NucUsb.NUC_CloseHandle();	

	switch(ack)
	{
		case MTP_KEY_SUCCESS:
			AfxMessageBox(_T("Burn successfully"));
		break;
		case MTP_NO_KEY:
			AfxMessageBox(_T("No key in MTP"));
		break;
		case MTP_LOCK_FAILED:
			AfxMessageBox(_T("Lock failed in MTP"));
		break;
		case MTP_LOCK_KEY:
			AfxMessageBox(_T("Failure. The key was locked in MTP"));
		break;
		case MTP_LOCK_SUCCESS:
			AfxMessageBox(_T("Lock successfully"));
		break;			
	}

	return TRUE;
}
/************** MTP End ************/